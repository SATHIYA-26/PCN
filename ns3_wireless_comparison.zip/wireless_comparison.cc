/*
 * NS-3 wireless technology comparison:
 *   - Wi-Fi infrastructure: 2 APs, one mobile STA per AP
 *   - Zigbee-style IEEE 802.15.4 LR-WPAN: 2 communicating nodes
 *   - Bluetooth-like short-range link abstraction: 2 mobile endpoints
 *
 * Sweeps RandomWalk2d speed values: 1, 2, 5, 10 m/s.
 *
 * IMPORTANT:
 * NS-3.42 (standard distribution) does not provide a complete native
 * Bluetooth Classic/BLE protocol stack. The Bluetooth scenario below is
 * explicitly a simplified point-to-point link abstraction, not a standards-
 * accurate Bluetooth PHY/MAC. See README.md before interpreting comparisons.
 *
 * CSV output: wireless_metrics.csv
 * RSSI samples: rssi_samples.csv
 *
 * This file uses common NS-3.42 helper patterns from the supplied lab cheat sheet.
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/propagation-module.h"
#include "ns3/lr-wpan-module.h"
#include "ns3/sixlowpan-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/flow-monitor-module.h"

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cmath>

using namespace ns3;

static std::ofstream g_rssi;
static std::string g_technology;
static double g_speed = 0.0;

static void
RecordWifiSignal(Ptr<const Packet> packet,
                 uint16_t channelFreqMhz,
                 WifiTxVector txVector,
                 MpduInfo aMpdu,
                 SignalNoiseDbm signalNoise,
                 uint16_t staId)
{
    g_rssi << g_technology << "," << g_speed << ","
           << Simulator::Now().GetSeconds() << ","
           << signalNoise.signal << ","
           << signalNoise.noise << "\n";
}

static void
RecordLrWpanSignal(std::string context,
                   Ptr<const Packet> packet,
                   uint32_t /*transmissionId*/,
                   uint8_t /*mpdu*/,
                   double rxPowerDbm)
{
    g_rssi << g_technology << "," << g_speed << ","
           << Simulator::Now().GetSeconds() << ","
           << rxPowerDbm << ",0\n";
}

static void
WriteMetrics(const std::string& technology,
             double speed,
             FlowMonitorHelper& flowHelper,
             Ptr<FlowMonitor> monitor,
             double simulationStop)
{
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowHelper.GetClassifier());
    const auto stats = monitor->GetFlowStats();

    uint64_t txPackets = 0;
    uint64_t rxPackets = 0;
    uint64_t rxBytes = 0;
    double delaySum = 0.0;
    double firstTx = simulationStop;
    double lastRx = 0.0;

    for (const auto& entry : stats)
    {
        const auto& s = entry.second;
        Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(entry.first);

        // Only include forward UDP data flow. Exclude reverse traffic.
        if (tuple.destinationPort != 9000)
        {
            continue;
        }

        txPackets += s.txPackets;
        rxPackets += s.rxPackets;
        rxBytes += s.rxBytes;
        delaySum += s.delaySum.GetSeconds();

        if (s.txPackets > 0)
        {
            firstTx = std::min(firstTx, s.timeFirstTxPacket.GetSeconds());
        }
        if (s.rxPackets > 0)
        {
            lastRx = std::max(lastRx, s.timeLastRxPacket.GetSeconds());
        }
    }

    double duration = (rxPackets > 0 && lastRx > firstTx) ? lastRx - firstTx : 0.0;
    double throughputMbps = duration > 0.0 ? (rxBytes * 8.0 / duration / 1e6) : 0.0;
    double avgDelayMs = rxPackets > 0 ? (delaySum / rxPackets * 1000.0) : 0.0;
    double packetLossPct = txPackets > 0
        ? (100.0 * static_cast<double>(txPackets - std::min(txPackets, rxPackets)) / txPackets)
        : 0.0;
    double pdrPct = txPackets > 0
        ? (100.0 * static_cast<double>(rxPackets) / txPackets)
        : 0.0;

    // Approximate RSSI is populated by technology-specific trace where available.
    // Bluetooth abstraction RSSI is estimated from endpoint separation in README.
    std::cout << technology << " speed=" << speed
              << " m/s | Tx=" << txPackets
              << " Rx=" << rxPackets
              << " Throughput=" << throughputMbps << " Mbps"
              << " Delay=" << avgDelayMs << " ms"
              << " Loss=" << packetLossPct << "%"
              << " PDR=" << pdrPct << "%\n";

    extern std::ofstream g_metrics;
    g_metrics << technology << "," << speed << ","
              << txPackets << "," << rxPackets << ","
              << throughputMbps << "," << avgDelayMs << ","
              << packetLossPct << "," << pdrPct << ","
              << (rxPackets > 0 ? static_cast<double>(rxBytes) / rxPackets : 0.0)
              << "\n";
}

std::ofstream g_metrics;

static void
RunWifi(double speed, double stopTime)
{
    g_technology = "WiFi";
    g_speed = speed;

    NodeContainer aps;
    aps.Create(2);
    NodeContainer stations;
    stations.Create(2);

    MobilityHelper apMobility;
    apMobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    apMobility.Install(aps);
    aps.Get(0)->GetObject<MobilityModel>()->SetPosition(Vector(0.0, 0.0, 0.0));
    aps.Get(1)->GetObject<MobilityModel>()->SetPosition(Vector(30.0, 0.0, 0.0));

    MobilityHelper staMobility;
    staMobility.SetPositionAllocator("ns3::GridPositionAllocator",
                                    "MinX", DoubleValue(5.0),
                                    "MinY", DoubleValue(5.0),
                                    "DeltaX", DoubleValue(30.0),
                                    "DeltaY", DoubleValue(0.0),
                                    "GridWidth", UintegerValue(2),
                                    "LayoutType", StringValue("RowFirst"));
    staMobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                                 "Bounds", RectangleValue(Rectangle(-10, 40, -20, 20)),
                                 "Speed", StringValue("ns3::ConstantRandomVariable[Constant=" +
                                                      std::to_string(speed) + "]"),
                                 "Time", TimeValue(Seconds(2.0)));
    staMobility.Install(stations);

    YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy;
    phy.SetChannel(channel.Create());
    phy.Set("TxPowerStart", DoubleValue(16.0));
    phy.Set("TxPowerEnd", DoubleValue(16.0));

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211n);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode", StringValue("HtMcs7"),
                                 "ControlMode", StringValue("HtMcs0"));
    WifiMacHelper mac;
    Ssid ssid = Ssid("wifi-compare");

    NetDeviceContainer apDevices;
    NetDeviceContainer staDevices;
    for (uint32_t i = 0; i < 2; ++i)
    {
        mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
        apDevices.Add(wifi.Install(phy, mac, aps.Get(i)));
        mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid),
                    "ActiveProbing", BooleanValue(false));
        staDevices.Add(wifi.Install(phy, mac, stations.Get(i)));
    }

    InternetStackHelper internet;
    internet.Install(aps);
    internet.Install(stations);

    Ipv4AddressHelper address;
    address.SetBase("10.10.0.0", "255.255.255.0");
    Ipv4InterfaceContainer apIf = address.Assign(apDevices);
    Ipv4InterfaceContainer staIf = address.Assign(staDevices);

    // Each mobile sends to its corresponding AP; one sink is installed per AP.
    for (uint32_t i = 0; i < 2; ++i)
    {
        UdpServerHelper server(9000);
        ApplicationContainer serverApp = server.Install(aps.Get(i));
        serverApp.Start(Seconds(0.2));
        serverApp.Stop(Seconds(stopTime));

        UdpClientHelper client(apIf.GetAddress(i), 9000);
        client.SetAttribute("MaxPackets", UintegerValue(1000000));
        client.SetAttribute("Interval", TimeValue(Seconds(0.02)));
        client.SetAttribute("PacketSize", UintegerValue(512));
        ApplicationContainer clientApp = client.Install(stations.Get(i));
        clientApp.Start(Seconds(1.0));
        clientApp.Stop(Seconds(stopTime - 0.1));
    }

    Config::ConnectWithoutContext(
        "/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/Phy/MonitorSnifferRx",
        MakeCallback(&RecordWifiSignal));

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();
    Simulator::Stop(Seconds(stopTime));
    Simulator::Run();
    WriteMetrics("WiFi", speed, flowHelper, monitor, stopTime);
    monitor->SerializeToXmlFile("wifi-flow-" + std::to_string(speed) + ".xml", true, true);
    Simulator::Destroy();
}

static void
RunZigbee(double speed, double stopTime)
{
    g_technology = "Zigbee";
    g_speed = speed;

    NodeContainer nodes;
    nodes.Create(2);

    MobilityHelper mobility;
    mobility.SetPositionAllocator("ns3::GridPositionAllocator",
                                  "MinX", DoubleValue(0.0),
                                  "MinY", DoubleValue(0.0),
                                  "DeltaX", DoubleValue(8.0),
                                  "DeltaY", DoubleValue(0.0),
                                  "GridWidth", UintegerValue(2),
                                  "LayoutType", StringValue("RowFirst"));
    mobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                              "Bounds", RectangleValue(Rectangle(-20, 30, -20, 20)),
                              "Speed", StringValue("ns3::ConstantRandomVariable[Constant=" +
                                                   std::to_string(speed) + "]"),
                              "Time", TimeValue(Seconds(2.0)));
    mobility.Install(nodes);

    LrWpanHelper lrWpan;
    NetDeviceContainer devices = lrWpan.Install(nodes);
    lrWpan.AssociateToPan(devices, 0);

    // The cheat-sheet approach uses 6LoWPAN to carry IPv6 over LR-WPAN.
    SixLowPanHelper sixLowPan;
    NetDeviceContainer sixDevices = sixLowPan.Install(devices);

    InternetStackHelper internet;
    internet.SetIpv4StackInstall(false);
    internet.Install(nodes);

    Ipv6AddressHelper ipv6;
    ipv6.SetBase(Ipv6Address("2001:1::"), Ipv6Prefix(64));
    Ipv6InterfaceContainer interfaces = ipv6.Assign(sixDevices);

    UdpServerHelper server(9000);
    ApplicationContainer serverApp = server.Install(nodes.Get(1));
    serverApp.Start(Seconds(0.2));
    serverApp.Stop(Seconds(stopTime));

    UdpClientHelper client(interfaces.GetAddress(1, 1), 9000);
    client.SetAttribute("MaxPackets", UintegerValue(1000000));
    client.SetAttribute("Interval", TimeValue(Seconds(0.25)));
    client.SetAttribute("PacketSize", UintegerValue(60)); // <= 80-byte guidance
    ApplicationContainer clientApp = client.Install(nodes.Get(0));
    clientApp.Start(Seconds(1.0));
    clientApp.Stop(Seconds(stopTime - 0.1));

    // LR-WPAN PHY trace path/name may vary by NS-3 release. This trace is
    // intended to capture receive power; check trace-source availability in
    // the installed version if it fails to connect.
    Config::ConnectWithoutContext(
        "/NodeList/*/DeviceList/*/$ns3::LrWpanNetDevice/Phy/PhyRxEnd",
        MakeCallback(&RecordLrWpanSignal));

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();
    Simulator::Stop(Seconds(stopTime));
    Simulator::Run();
    WriteMetrics("Zigbee", speed, flowHelper, monitor, stopTime);
    monitor->SerializeToXmlFile("zigbee-flow-" + std::to_string(speed) + ".xml", true, true);
    Simulator::Destroy();
}

static void
RunBluetoothAbstraction(double speed, double stopTime)
{
    g_technology = "Bluetooth-Model";
    g_speed = speed;

    NodeContainer nodes;
    nodes.Create(2);

    MobilityHelper mobility;
    mobility.SetPositionAllocator("ns3::GridPositionAllocator",
                                  "MinX", DoubleValue(0.0),
                                  "MinY", DoubleValue(0.0),
                                  "DeltaX", DoubleValue(4.0),
                                  "DeltaY", DoubleValue(0.0),
                                  "GridWidth", UintegerValue(2),
                                  "LayoutType", StringValue("RowFirst"));
    mobility.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                              "Bounds", RectangleValue(Rectangle(-10, 20, -10, 10)),
                              "Speed", StringValue("ns3::ConstantRandomVariable[Constant=" +
                                                   std::to_string(speed) + "]"),
                              "Time", TimeValue(Seconds(2.0)));
    mobility.Install(nodes);

    // Approximation: wired point-to-point channel used as a short-range
    // Bluetooth-like application link. This is NOT a Bluetooth radio model.
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("2Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("1ms"));
    p2p.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("50p"));
    NetDeviceContainer devices = p2p.Install(nodes);

    InternetStackHelper internet;
    internet.Install(nodes);
    Ipv4AddressHelper address;
    address.SetBase("10.30.0.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces = address.Assign(devices);

    UdpServerHelper server(9000);
    ApplicationContainer serverApp = server.Install(nodes.Get(1));
    serverApp.Start(Seconds(0.2));
    serverApp.Stop(Seconds(stopTime));

    UdpClientHelper client(interfaces.GetAddress(1), 9000);
    client.SetAttribute("MaxPackets", UintegerValue(1000000));
    client.SetAttribute("Interval", TimeValue(Seconds(0.02)));
    client.SetAttribute("PacketSize", UintegerValue(256));
    ApplicationContainer clientApp = client.Install(nodes.Get(0));
    clientApp.Start(Seconds(1.0));
    clientApp.Stop(Seconds(stopTime - 0.1));

    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();
    Simulator::Stop(Seconds(stopTime));
    Simulator::Run();
    WriteMetrics("Bluetooth-Model", speed, flowHelper, monitor, stopTime);
    monitor->SerializeToXmlFile("bluetooth-model-flow-" + std::to_string(speed) + ".xml", true, true);

    // Estimated signal power using a log-distance path-loss expression.
    // This is only a rough illustration, not a Bluetooth PHY measurement.
    Ptr<MobilityModel> a = nodes.Get(0)->GetObject<MobilityModel>();
    Ptr<MobilityModel> b = nodes.Get(1)->GetObject<MobilityModel>();
    double distance = std::max(1.0, a->GetDistanceFrom(b));
    double estimatedRssi = -40.0 - 20.0 * std::log10(distance);
    g_rssi << "Bluetooth-Model," << speed << ","
           << Simulator::Now().GetSeconds() << ","
           << estimatedRssi << ",0\n";

    Simulator::Destroy();
}

int
main(int argc, char* argv[])
{
    double stopTime = 20.0;
    CommandLine cmd(__FILE__);
    cmd.AddValue("stopTime", "Simulation stop time in seconds", stopTime);
    cmd.Parse(argc, argv);

    g_metrics.open("wireless_metrics.csv", std::ios::out);
    g_metrics << "technology,speed_mps,tx_packets,rx_packets,throughput_mbps,"
                 "avg_delay_ms,packet_loss_pct,pdr_pct,avg_rx_bytes_per_packet\n";

    g_rssi.open("rssi_samples.csv", std::ios::out);
    g_rssi << "technology,speed_mps,time_s,rx_signal_dbm,noise_dbm\n";

    const std::vector<double> speeds = {1.0, 2.0, 5.0, 10.0};
    for (double speed : speeds)
    {
        RunWifi(speed, stopTime);
        RunZigbee(speed, stopTime);
        RunBluetoothAbstraction(speed, stopTime);
    }

    g_metrics.close();
    g_rssi.close();
    std::cout << "\nSaved wireless_metrics.csv and rssi_samples.csv\n";
    return 0;
}
