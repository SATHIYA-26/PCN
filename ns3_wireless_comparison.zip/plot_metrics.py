#!/usr/bin/env python3
"""
Plot NS-3 wireless comparison CSV results.

Run from the directory containing wireless_metrics.csv:
    python3 plot_metrics.py

Creates PNG charts under ./graphs and a summary CSV of average RSSI samples.
Requires pandas and matplotlib:
    python3 -m pip install pandas matplotlib
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parent
METRICS_FILE = BASE / "wireless_metrics.csv"
RSSI_FILE = BASE / "rssi_samples.csv"
OUT_DIR = BASE / "graphs"
OUT_DIR.mkdir(exist_ok=True)

if not METRICS_FILE.exists():
    raise SystemExit(
        f"Missing {METRICS_FILE.name}. Run the NS-3 C++ simulation first "
        "from this directory (or copy its CSV output here)."
    )

df = pd.read_csv(METRICS_FILE)
required = {
    "technology", "speed_mps", "throughput_mbps", "avg_delay_ms",
    "packet_loss_pct", "pdr_pct", "tx_packets", "rx_packets"
}
missing = required - set(df.columns)
if missing:
    raise SystemExit(f"CSV is missing columns: {sorted(missing)}")

metrics = [
    ("throughput_mbps", "Throughput (Mbps)", "throughput.png"),
    ("avg_delay_ms", "Average end-to-end delay (ms)", "delay.png"),
    ("packet_loss_pct", "Packet loss (%)", "packet_loss.png"),
    ("pdr_pct", "Packet delivery ratio (PDR %)", "pdr.png"),
]

for column, ylabel, filename in metrics:
    fig, ax = plt.subplots(figsize=(8, 5))
    for technology, group in df.groupby("technology"):
        group = group.sort_values("speed_mps")
        ax.plot(group["speed_mps"], group[column], marker="o", label=technology)
    ax.set_xlabel("RandomWalk speed (m/s)")
    ax.set_ylabel(ylabel)
    ax.set_title(f"Wi-Fi vs Zigbee vs Bluetooth model: {ylabel}")
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_DIR / filename, dpi=160)
    plt.close(fig)

# Tx/Rx packet comparison as an additional graph.
fig, ax = plt.subplots(figsize=(8, 5))
for technology, group in df.groupby("technology"):
    group = group.sort_values("speed_mps")
    ax.plot(group["speed_mps"], group["tx_packets"], marker="o",
            linestyle="--", label=f"{technology} Tx")
    ax.plot(group["speed_mps"], group["rx_packets"], marker="s",
            label=f"{technology} Rx")
ax.set_xlabel("RandomWalk speed (m/s)")
ax.set_ylabel("Packets")
ax.set_title("Transmitted and received packets")
ax.grid(True, alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig(OUT_DIR / "tx_rx_packets.png", dpi=160)
plt.close(fig)

if RSSI_FILE.exists():
    rssi = pd.read_csv(RSSI_FILE)
    if {"technology", "speed_mps", "rx_signal_dbm"}.issubset(rssi.columns):
        # Only finite numeric RSSI values are included.
        rssi["rx_signal_dbm"] = pd.to_numeric(rssi["rx_signal_dbm"], errors="coerce")
        rssi = rssi.dropna(subset=["rx_signal_dbm"])
        if not rssi.empty:
            summary = (
                rssi.groupby(["technology", "speed_mps"], as_index=False)
                ["rx_signal_dbm"].mean()
                .rename(columns={"rx_signal_dbm": "mean_rx_signal_dbm"})
            )
            summary.to_csv(OUT_DIR / "mean_rssi.csv", index=False)

            fig, ax = plt.subplots(figsize=(8, 5))
            for technology, group in summary.groupby("technology"):
                group = group.sort_values("speed_mps")
                ax.plot(group["speed_mps"], group["mean_rx_signal_dbm"],
                        marker="o", label=technology)
            ax.set_xlabel("RandomWalk speed (m/s)")
            ax.set_ylabel("Mean received signal power (dBm)")
            ax.set_title("Mean received signal strength")
            ax.grid(True, alpha=0.3)
            ax.legend()
            fig.tight_layout()
            fig.savefig(OUT_DIR / "rssi.png", dpi=160)
            plt.close(fig)

print(f"Graphs saved in: {OUT_DIR}")
print("Created: throughput.png, delay.png, packet_loss.png, pdr.png, "
      "tx_rx_packets.png, and (if RSSI data exists) rssi.png")
