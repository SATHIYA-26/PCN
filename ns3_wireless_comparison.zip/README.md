# NS-3 Wireless Technology Performance Comparison

## Files in this ZIP

1. `wireless_comparison.cc` — NS-3 C++ simulation.
2. `plot_metrics.py` — Python script to graph the CSV output.
3. `README.md` — setup, build, run, output, and interpretation guide.

## What the simulation models

The program sweeps RandomWalk2d speeds of **1, 2, 5, and 10 m/s** and records
performance metrics for three technology cases:

- **Wi-Fi:** infrastructure-mode 802.11n with **two APs** and two mobile stations
  (one station associated with each AP). Each station generates UDP traffic
  to its AP.
- **Zigbee:** two communicating nodes using IEEE 802.15.4 LR-WPAN with 6LoWPAN
  and IPv6. The application payload is kept small (60 bytes).
- **Bluetooth-Model:** two mobile endpoints exchanging UDP traffic over a
  point-to-point link abstraction.

### Important Bluetooth limitation

The standard NS-3.42 distribution does not include a full native Bluetooth
Classic/BLE PHY and MAC model. Therefore, the Bluetooth case in this project is
an explicitly labeled **link abstraction**, not a standards-accurate Bluetooth
simulation. It can provide a basic comparison of traffic metrics under the
chosen abstraction, but it must not be presented as measured Bluetooth PHY/MAC
performance. Its RSSI value is estimated from distance with a simple path-loss
expression and is not a radio trace.

For an academically valid Bluetooth comparison, use a Bluetooth-capable
simulator/model (or a documented third-party NS-3 Bluetooth module) and replace
this abstraction. Wi-Fi and LR-WPAN RSSI are trace-based where the relevant
trace source is available in the installed NS-3 version.

## Performance metrics

The C++ code writes `wireless_metrics.csv` with:

- **Throughput (Mbps):** received application-flow bytes × 8 divided by the
  measured first-transmission-to-last-reception interval.
- **Average end-to-end delay (ms):** FlowMonitor delay sum divided by received
  packets, converted to milliseconds.
- **Packet loss (%):** `(Tx packets - Rx packets) / Tx packets × 100`.
- **PDR (%):** `Rx packets / Tx packets × 100`.
- Tx and Rx packet counts, and average received bytes per packet.

The `rssi_samples.csv` file contains RSSI / received-power samples and noise
where a PHY trace reports them. Bluetooth-Model RSSI is a one-time estimate at
the end of the scenario.

> PDR and packet loss are complements when calculated from the same Tx/Rx
> packet counts. FlowMonitor may classify additional flows in some topologies;
> the code filters the UDP data flow using destination port 9000.

## Prerequisites

- NS-3.42 (or a compatible NS-3 release with the listed modules).
- A C++ compiler supported by that NS-3 release.
- Python 3.
- Python packages: `pandas` and `matplotlib`.

The C++ simulation follows the module/helper conventions in the supplied
Computer Networks lab cheat sheet. A trace-source path can differ between
NS-3 releases; if NS-3 reports that the LR-WPAN trace source is not found,
check the trace-source names in that version's LR-WPAN PHY documentation and
adjust the `Config::ConnectWithoutContext` path.

## Step-by-step: run the C++ simulation

### 1. Open your NS-3 directory

For example (change this to your actual NS-3 folder):

```bash
cd ~/ns-3.42
```

Check the NS-3 wrapper exists:

```bash
ls
```

You should see the `ns3` wrapper and `scratch` directory.

### 2. Copy the C++ file into `scratch`

If this ZIP was extracted to `~/Downloads/ns3_wireless_comparison`:

```bash
cp ~/Downloads/ns3_wireless_comparison/wireless_comparison.cc scratch/wireless_comparison.cc
```

Adjust the source path if you extracted it somewhere else.

### 3. Build NS-3

```bash
./ns3 build
```

If the build fails, inspect the compiler error. NS-3 API/trace-source names may
need adjustment for your exact version.

### 4. Run the simulation

```bash
./ns3 run scratch/wireless_comparison
```

To change the simulation duration (default is 20 seconds):

```bash
./ns3 run "scratch/wireless_comparison --stopTime=30"
```

The simulation runs all 3 cases at each of the 4 speeds. It can take some time.

### 5. Locate the output files

The program writes output into the current NS-3 run directory, normally the
NS-3 project root:

- `wireless_metrics.csv`
- `rssi_samples.csv`
- Per-run FlowMonitor XML files, such as `wifi-flow-1.000000.xml`

If you prefer to keep the outputs together with the Python script, copy them
there:

```bash
cp wireless_metrics.csv rssi_samples.csv ~/Downloads/ns3_wireless_comparison/
```

## Step-by-step: create graphs with Python

### 6. Install Python packages

```bash
python3 -m pip install pandas matplotlib
```

If your machine has no Internet, install these packages beforehand or use a
Python environment where they are already installed.

### 7. Run the graph script

```bash
cd ~/Downloads/ns3_wireless_comparison
python3 plot_metrics.py
```

### 8. Graph output

A `graphs` folder is created with:

- `throughput.png` — throughput vs speed
- `delay.png` — average delay vs speed
- `packet_loss.png` — packet loss vs speed
- `pdr.png` — PDR vs speed
- `tx_rx_packets.png` — Tx/Rx packet counts vs speed
- `rssi.png` — mean received signal power vs speed, if RSSI rows exist
- `mean_rssi.csv` — mean RSSI table, if RSSI rows exist

Each plot compares the available technology labels on the same axes.

## Notes for report/viva

- A RandomWalk speed setting is a mobility speed in metres per second.
- Higher mobility can change node separation and therefore propagation loss,
  link quality, retransmissions, and end-to-end metrics.
- Wi-Fi infrastructure mode uses APs; Zigbee here uses LR-WPAN/6LoWPAN.
- Bluetooth-Model is an abstraction only. Clearly state that limitation in
  reports and do not label its RSSI as a measured Bluetooth signal.
- Results depend on NS-3 version, simulation duration, mobility bounds,
  application packet size/rate, propagation model, and trace-source behavior.
- This starter project is intended as a basic lab exercise, not a calibrated
  or publication-grade cross-technology benchmark.

## Troubleshooting

### `./ns3 build` fails

Check that the NS-3 version includes `wifi`, `lr-wpan`, `sixlowpan`,
`point-to-point`, `flow-monitor`, and application modules. Read the first
compiler error and resolve that API mismatch before rebuilding.

### Missing LR-WPAN trace source

The `PhyRxEnd` trace signature/name can vary. Look up the available LR-WPAN
PHY trace sources for your exact NS-3 version and update the callback and
connection path. Do not treat an empty RSSI file as valid measured signal data.

### Python says a package is missing

Install the dependency:

```bash
python3 -m pip install pandas matplotlib
```

### CSV not found

Run the C++ simulation first, then copy `wireless_metrics.csv` and
`rssi_samples.csv` to the folder containing `plot_metrics.py`.
