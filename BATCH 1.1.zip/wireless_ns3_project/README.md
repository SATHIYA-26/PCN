# Wireless Technology Comparison — ns-3.42

This project compares:
1. **Wi-Fi**: two AP/STA pairs using IEEE 802.11g; each STA sends UDP traffic to its AP.
2. **Zigbee-style low-power link**: two IEEE 802.15.4 (LR-WPAN) nodes with 6LoWPAN/IPv6 and UDP traffic.
3. **Bluetooth-like approximation**: two mobile devices using an 802.11b ad-hoc link configured at 1 Mbps and 0 dBm.

> **Important limitation:** stock ns-3.42 does not provide a native Bluetooth model. The third case is explicitly an 802.11b-based approximation, not a Bluetooth simulation. The Zigbee case uses LR-WPAN + 6LoWPAN, which is a simulation of a low-power 802.15.4/IPv6 link rather than a complete Zigbee protocol stack.

## Files
- `wireless_comparison.cc` — C++ simulation.
- `plot_results.py` — plots metrics from the CSV output.
- `README.md` — these instructions.

## Requirements
- ns-3.42 source tree with `wifi`, `lr-wpan`, `sixlowpan`, `applications`, `internet`, `mobility`, and `flow-monitor` modules enabled.
- Python 3, `pandas`, and `matplotlib` for graphs.

Install plotting packages:
```bash
python3 -m pip install pandas matplotlib
```

## Install the C++ file into ns-3.42
1. Extract/open your ns-3.42 folder.
2. Copy `wireless_comparison.cc` into the `scratch` directory. Example:
   `ns-3.42/scratch/wireless_comparison.cc`
3. Open a terminal in the root `ns-3.42` directory (the directory containing the `ns3` script).

## Build and test in stages
First run a short Wi-Fi-only case:
```bash
./ns3 run "scratch/wireless_comparison --tech=wifi --simTime=10 --runs=1"
```
Then test Zigbee-style LR-WPAN/6LoWPAN:
```bash
./ns3 run "scratch/wireless_comparison --tech=zigbee --simTime=10 --runs=1"
```
Then test the Bluetooth-like approximation:
```bash
./ns3 run "scratch/wireless_comparison --tech=bluetooth --simTime=10 --runs=1"
```
Finally run all technologies:
```bash
./ns3 run "scratch/wireless_comparison --runs=1"
```
If your local ns-3.42 build uses a different scratch target naming convention, use the exact target form shown by `./ns3 run --help` or the scratch examples in your tree.

## Outputs
The program writes these files in the **current working directory**:
- `results.csv`: one row for each technology, speed, and run.
- `rss_trace.csv`: distance-based RSS estimates sampled every 0.5 seconds.

Default run: 3 technologies × 4 speeds (1, 2, 5, 10 m/s) × 3 repetitions = 36 simulations. Use `--runs=1` for a quick test.

Metrics in `results.csv`:
- `tx_packets`, `rx_packets`, `lost_packets`
- `pdr_percent`, `loss_percent`
- `throughput_kbps`, `avg_delay_ms`, `avg_jitter_ms`
- `avg_rss_dbm`

RSS is **estimated from transmit power and modeled path loss based on node distance**; it is not read from a physical receiver's RSS trace. Packet loss is calculated as transmitted packets minus received packets after the simulation has run.

## Plot the results
Run this from the directory containing `results.csv` and `rss_trace.csv`:
```bash
python3 plot_results.py
```
If running on Windows, use `python plot_results.py`.

## Important honesty note
The source was revised to fix the previous IPv4/IPv6 application mismatch and avoid passing raw IP addresses through ambiguous `Address(...)` conversions. However, this environment does not contain an ns-3.42 installation, so I cannot claim that it has been compiled or runtime-tested here. Please run the three staged test commands above; if your ns-3.42 tree reports an error, send the **first complete compiler/runtime error** rather than only a screenshot of the final line.
