/*
 * wireless_comparison.cc
 *
 * Compares three short-range wireless technologies in ns-3 under RandomWalk mobility:
 *
 *   1. Wi-Fi      : 2 Access Points (APs) + 2 mobile stations (802.11g)
 *   2. ZigBee     : 2 mobile nodes (IEEE 802.15.4 radio + 6LoWPAN/IPv6)
 *   3. Bluetooth  : 2 mobile nodes (APPROXIMATED: 1 Mbps, 0 dBm, short-range radio,
 *                   because ns-3 has no official Bluetooth model)
 *
 * For every technology and every node speed (1, 2, 5, 10 m/s) the program runs the
 * simulation `runs` times (different random seeds) and records:
 *     throughput, average delay, jitter, packets sent/received/lost,
 *     packet delivery ratio (PDR), packet loss %, distance-based RSS estimate (not a direct PHY receiver measurement).
 *
 * Output files (written in the folder you run the program from):
 *     results.csv     -> one row per simulation (used by plot_results.py)
 *     rss_trace.csv   -> RSS sampled every 0.5 s (used by plot_results.py)
 *
 * Target: ns-3.42. Compile and run in an ns-3.42 source tree; this package has not been compiled in this environment.
 */

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/internet-module.h"
#include "ns3/lr-wpan-module.h"
#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/propagation-module.h"
#include "ns3/sixlowpan-module.h"
#include "ns3/wifi-module.h"

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("WirelessComparison");

// ----------------------------------------------------------------------------
// Simple data holders
// ----------------------------------------------------------------------------

// Settings shared by all simulations
struct Params
{
    double simTime;      // total traffic stop time (s)
    uint32_t pktSize;    // UDP payload size (bytes)
    double intervalMs;   // gap between packets of one flow (ms)
    double appStart;     // when traffic starts (s) - gives Wi-Fi time to associate
};

// One row of results.csv
struct Result
{
    std::string tech;
    double speed = 0;
    uint32_t run = 0;
    uint64_t tx = 0;
    uint64_t rx = 0;
    uint64_t lost = 0;
    double pdr = 0;        // %
    double lossPct = 0;    // %
    double thrKbps = 0;    // kbit/s (application-level goodput)
    double delayMs = 0;    // ms
    double jitterMs = 0;   // ms
    double rssDbm = 0;     // modeled dBm estimate
};

// Estimates RSS periodically from node distance using a LogDistancePropagationLossModel
struct RssRecorder
{
    Ptr<LogDistancePropagationLossModel> model;
    double txPowerDbm = 0;
    std::vector<std::pair<Ptr<Node>, Ptr<Node>>> links; // (sender, receiver)
    double sum = 0;
    uint32_t count = 0;
    std::ofstream* trace = nullptr;
    std::string tech;
    double speed = 0;
    uint32_t run = 0;
    double stopTime = 0;
};

// Called every 0.5 s: RSS estimate = TxPower - modeled path loss (not a PHY receiver trace)
static void
SampleRss(RssRecorder* r)
{
    double t = Simulator::Now().GetSeconds();
    if (t > r->stopTime)
    {
        return;
    }
    for (uint32_t i = 0; i < r->links.size(); ++i)
    {
        Ptr<MobilityModel> a = r->links[i].first->GetObject<MobilityModel>();
        Ptr<MobilityModel> b = r->links[i].second->GetObject<MobilityModel>();
        double rss = r->model->CalcRxPower(r->txPowerDbm, a, b);
        r->sum += rss;
        r->count++;
        if (r->trace)
        {
            *(r->trace) << r->tech << "," << r->speed << "," << r->run << "," << t << "," << i
                        << "," << rss << "\n";
        }
    }
    Simulator::Schedule(Seconds(0.5), &SampleRss, r);
}

// ----------------------------------------------------------------------------
// Helper functions
// ----------------------------------------------------------------------------

// Put nodes in a 50 m x 50 m area and move them with RandomWalk2d at a fixed speed.
static void
InstallRandomWalk(NodeContainer nodes, Ptr<ListPositionAllocator> start, double speed)
{
    std::ostringstream spd;
    spd << "ns3::ConstantRandomVariable[Constant=" << speed << "]";

    MobilityHelper mob;
    mob.SetPositionAllocator(start);
    mob.SetMobilityModel("ns3::RandomWalk2dMobilityModel",
                         "Bounds",
                         RectangleValue(Rectangle(0, 50, 0, 50)),
                         "Speed",
                         StringValue(spd.str()),
                         "Mode",
                         EnumValue(RandomWalk2dMobilityModel::MODE_TIME),
                         "Time",
                         TimeValue(Seconds(1.0)));
    mob.Install(nodes);
}

// UDP receiver on an IPv4 node.
static void
InstallServer4(Ptr<Node> node, uint16_t port, const Params& p)
{
    PacketSinkHelper sink("ns3::UdpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer app = sink.Install(node);
    app.Start(Seconds(1.0));
    app.Stop(Seconds(p.simTime + 0.5));
}

// UDP receiver on an IPv6 node (used by the 6LoWPAN/Zigbee scenario).
static void
InstallServer6(Ptr<Node> node, uint16_t port, const Params& p)
{
    PacketSinkHelper sink("ns3::UdpSocketFactory",
                          Inet6SocketAddress(Ipv6Address::GetAny(), port));
    ApplicationContainer app = sink.Install(node);
    app.Start(Seconds(1.0));
    app.Stop(Seconds(p.simTime + 0.5));
}

// Constant-rate UDP traffic over IPv4.
static void
InstallClient4(Ptr<Node> node, Ipv4Address dst, uint16_t port, const Params& p)
{
    OnOffHelper client("ns3::UdpSocketFactory", InetSocketAddress(dst, port));
    client.SetConstantRate(DataRate(static_cast<uint64_t>(p.pktSize * 8.0 * 1000.0 / p.intervalMs)),
                           p.pktSize);
    ApplicationContainer app = client.Install(node);
    app.Start(Seconds(p.appStart));
    app.Stop(Seconds(p.simTime));
}

// Constant-rate UDP traffic over IPv6.
static void
InstallClient6(Ptr<Node> node, Ipv6Address dst, uint16_t port, const Params& p)
{
    OnOffHelper client("ns3::UdpSocketFactory", Inet6SocketAddress(dst, port));
    client.SetConstantRate(DataRate(static_cast<uint64_t>(p.pktSize * 8.0 * 1000.0 / p.intervalMs)),
                           p.pktSize);
    ApplicationContainer app = client.Install(node);
    app.Start(Seconds(p.appStart));
    app.Stop(Seconds(p.simTime));
}

// ----------------------------------------------------------------------------
// One complete simulation (build topology -> traffic -> run -> collect metrics)
// ----------------------------------------------------------------------------
static Result
RunOne(const std::string& tech,
       double speed,
       uint32_t run,
       const Params& p,
       std::ofstream& rssFile)
{
    RngSeedManager::SetSeed(12345);
    RngSeedManager::SetRun(run);

    RssRecorder rec;
    rec.model = CreateObject<LogDistancePropagationLossModel>(); // same formula the channels use
    rec.trace = &rssFile;
    rec.tech = tech;
    rec.speed = speed;
    rec.run = run;
    rec.stopTime = p.simTime;

    const uint16_t port = 9;

    if (tech == "wifi")
    {
        // ------------------------------------------------------------ Wi-Fi
        // Topology:  AP0 (12.5,25)   AP1 (37.5,25)   fixed
        //            STA0 -> AP0     STA1 -> AP1     STAs move (RandomWalk)
        NodeContainer aps;
        NodeContainer stas;
        aps.Create(2);
        stas.Create(2);

        // fixed APs
        Ptr<ListPositionAllocator> apPos = CreateObject<ListPositionAllocator>();
        apPos->Add(Vector(12.5, 25.0, 0.0));
        apPos->Add(Vector(37.5, 25.0, 0.0));
        MobilityHelper apMob;
        apMob.SetPositionAllocator(apPos);
        apMob.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        apMob.Install(aps);

        // moving stations
        Ptr<ListPositionAllocator> staPos = CreateObject<ListPositionAllocator>();
        staPos->Add(Vector(17.5, 25.0, 0.0));
        staPos->Add(Vector(32.5, 25.0, 0.0));
        InstallRandomWalk(stas, staPos, speed);

        // radio channel + devices
        YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
        YansWifiPhyHelper phy;
        phy.SetChannel(channel.Create());

        WifiHelper wifi;
        wifi.SetStandard(WIFI_STANDARD_80211g);
        wifi.SetRemoteStationManager("ns3::IdealWifiManager");

        WifiMacHelper mac;
        NetDeviceContainer apDev;
        NetDeviceContainer staDev;
        for (uint32_t i = 0; i < 2; ++i)
        {
            Ssid ssid = Ssid("wifi-" + std::to_string(i));
            mac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid), "ActiveProbing", BooleanValue(true));
            staDev.Add(wifi.Install(phy, mac, stas.Get(i)));
            mac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid));
            apDev.Add(wifi.Install(phy, mac, aps.Get(i)));
        }

        // IP addresses: one small subnet per AP/STA pair
        InternetStackHelper stack;
        stack.Install(aps);
        stack.Install(stas);

        Ipv4AddressHelper addr;
        NetDeviceContainer pair0;
        pair0.Add(apDev.Get(0));
        pair0.Add(staDev.Get(0));
        NetDeviceContainer pair1;
        pair1.Add(apDev.Get(1));
        pair1.Add(staDev.Get(1));
        addr.SetBase("10.1.1.0", "255.255.255.0");
        Ipv4InterfaceContainer if0 = addr.Assign(pair0); // index 0 = AP0, 1 = STA0
        addr.SetBase("10.1.2.0", "255.255.255.0");
        Ipv4InterfaceContainer if1 = addr.Assign(pair1);

        // traffic: each STA sends UDP to its own AP
        InstallServer4(aps.Get(0), port, p);
        InstallServer4(aps.Get(1), port, p);
        InstallClient4(stas.Get(0), if0.GetAddress(0), port, p);
        InstallClient4(stas.Get(1), if1.GetAddress(0), port, p);

        rec.txPowerDbm = 16.0206; // ns-3 default Wi-Fi transmit power
        rec.links.push_back(std::make_pair(stas.Get(0), aps.Get(0)));
        rec.links.push_back(std::make_pair(stas.Get(1), aps.Get(1)));
    }
    else if (tech == "bluetooth")
    {
        // ------------------------------------------------------- Bluetooth (approx.)
        // Two mobile devices, 1 Mbps DSSS radio, 0 dBm (Bluetooth class-3 like power).
        NodeContainer nodes;
        nodes.Create(2);

        Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator>();
        pos->Add(Vector(20.0, 25.0, 0.0));
        pos->Add(Vector(30.0, 25.0, 0.0));
        InstallRandomWalk(nodes, pos, speed);

        YansWifiChannelHelper channel = YansWifiChannelHelper::Default();
        YansWifiPhyHelper phy;
        phy.SetChannel(channel.Create());
        phy.Set("TxPowerStart", DoubleValue(0.0));
        phy.Set("TxPowerEnd", DoubleValue(0.0));

        WifiHelper wifi;
        wifi.SetStandard(WIFI_STANDARD_80211b);
        wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                     "DataMode",
                                     StringValue("DsssRate1Mbps"),
                                     "ControlMode",
                                     StringValue("DsssRate1Mbps"));
        WifiMacHelper mac;
        mac.SetType("ns3::AdhocWifiMac");
        NetDeviceContainer dev = wifi.Install(phy, mac, nodes);

        InternetStackHelper stack;
        stack.Install(nodes);
        Ipv4AddressHelper addr;
        addr.SetBase("10.2.1.0", "255.255.255.0");
        Ipv4InterfaceContainer ifc = addr.Assign(dev);

        // traffic both ways: node0 -> node1 and node1 -> node0
        InstallServer4(nodes.Get(0), port, p);
        InstallServer4(nodes.Get(1), port, p);
        InstallClient4(nodes.Get(0), ifc.GetAddress(1), port, p);
        InstallClient4(nodes.Get(1), ifc.GetAddress(0), port, p);

        rec.txPowerDbm = 0.0;
        rec.links.push_back(std::make_pair(nodes.Get(0), nodes.Get(1)));
        rec.links.push_back(std::make_pair(nodes.Get(1), nodes.Get(0)));
    }
    else
    {
        // ------------------------------------------------------------ ZigBee
        // IEEE 802.15.4 radio (250 kbps, 0 dBm) + 6LoWPAN + IPv6 + UDP.
        NodeContainer nodes;
        nodes.Create(2);

        Ptr<ListPositionAllocator> pos = CreateObject<ListPositionAllocator>();
        pos->Add(Vector(20.0, 25.0, 0.0));
        pos->Add(Vector(30.0, 25.0, 0.0));
        InstallRandomWalk(nodes, pos, speed); // mobility BEFORE devices

        LrWpanHelper lrWpan;
        NetDeviceContainer lrDev = lrWpan.Install(nodes);
        lrWpan.AssociateToPan(lrDev, 0);

        SixLowPanHelper sixlow;
        NetDeviceContainer dev = sixlow.Install(lrDev);

        InternetStackHelper stack;
        stack.SetIpv4StackInstall(false);
        stack.Install(nodes);

        Ipv6AddressHelper addr;
        addr.SetBase(Ipv6Address("2001:db8::"), Ipv6Prefix(64));
        Ipv6InterfaceContainer ifc = addr.Assign(dev); // index 0 = link-local, 1 = global

        InstallServer6(nodes.Get(0), port, p);
        InstallServer6(nodes.Get(1), port, p);
        InstallClient6(nodes.Get(0), ifc.GetAddress(1, 1), port, p);
        InstallClient6(nodes.Get(1), ifc.GetAddress(0, 1), port, p);

        rec.txPowerDbm = 0.0;
        rec.links.push_back(std::make_pair(nodes.Get(0), nodes.Get(1)));
        rec.links.push_back(std::make_pair(nodes.Get(1), nodes.Get(0)));
    }

    // ---------------------------------------------------------------- measuring
    FlowMonitorHelper fmHelper;
    Ptr<FlowMonitor> monitor = fmHelper.InstallAll();

    Simulator::Schedule(Seconds(p.appStart), &SampleRss, &rec);
    Simulator::Stop(Seconds(p.simTime + 1.0));
    Simulator::Run();
    monitor->CheckForLostPackets();

    Result r;
    r.tech = tech;
    r.speed = speed;
    r.run = run;

    double delaySum = 0;
    double jitterSum = 0;
    uint64_t jitterCount = 0;

    Ptr<Ipv4FlowClassifier> c4 = DynamicCast<Ipv4FlowClassifier>(fmHelper.GetClassifier());
    Ptr<Ipv6FlowClassifier> c6 = DynamicCast<Ipv6FlowClassifier>(fmHelper.GetClassifier6());

    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();
    for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator it = stats.begin();
         it != stats.end();
         ++it)
    {
        // keep only UDP flows (protocol 17); this skips ICMPv6 neighbour-discovery packets
        bool isUdp = false;
        if (tech == "zigbee")
        {
            Ipv6FlowClassifier::FiveTuple t = c6->FindFlow(it->first);
            isUdp = (t.protocol == 17);
        }
        else
        {
            Ipv4FlowClassifier::FiveTuple t = c4->FindFlow(it->first);
            isUdp = (t.protocol == 17);
        }
        if (!isUdp)
        {
            continue;
        }

        r.tx += it->second.txPackets;
        r.rx += it->second.rxPackets;
        delaySum += it->second.delaySum.GetSeconds();
        if (it->second.rxPackets > 1)
        {
            jitterSum += it->second.jitterSum.GetSeconds();
            jitterCount += it->second.rxPackets - 1;
        }
    }

    r.lost = (r.tx > r.rx) ? (r.tx - r.rx) : 0;
    r.pdr = (r.tx > 0) ? 100.0 * (double)r.rx / (double)r.tx : 0.0;
    r.lossPct = 100.0 - r.pdr;
    double activeTime = p.simTime - p.appStart;
    r.thrKbps = (double)r.rx * p.pktSize * 8.0 / activeTime / 1000.0;
    r.delayMs = (r.rx > 0) ? 1000.0 * delaySum / (double)r.rx : 0.0;
    r.jitterMs = (jitterCount > 0) ? 1000.0 * jitterSum / (double)jitterCount : 0.0;
    r.rssDbm = (rec.count > 0) ? rec.sum / rec.count : 0.0;

    Simulator::Destroy();
    return r;
}

// ----------------------------------------------------------------------------
// main
// ----------------------------------------------------------------------------
int
main(int argc, char* argv[])
{
    Params p;
    p.simTime = 60.0;
    p.pktSize = 64;
    p.intervalMs = 20.0;
    p.appStart = 2.0;

    uint32_t runs = 3;
    std::string tech = "all";
    std::string outFile = "results.csv";
    std::string rssOut = "rss_trace.csv";

    CommandLine cmd(__FILE__);
    cmd.AddValue("simTime", "Simulation (traffic) time in seconds", p.simTime);
    cmd.AddValue("pktSize", "UDP payload size in bytes", p.pktSize);
    cmd.AddValue("interval", "Packet interval per flow in milliseconds", p.intervalMs);
    cmd.AddValue("runs", "Number of repetitions (random seeds) per case", runs);
    cmd.AddValue("tech", "wifi | zigbee | bluetooth | all", tech);
    cmd.AddValue("out", "Results CSV file name", outFile);
    cmd.AddValue("rssOut", "RSS trace CSV file name", rssOut);
    cmd.Parse(argc, argv);

    if (runs == 0 || p.simTime <= p.appStart || p.intervalMs <= 0.0 || p.pktSize < 1)
    {
        std::cerr << "Invalid parameters: runs must be > 0, simTime > appStart, "
                     "interval > 0, and pktSize > 0." << std::endl;
        return 1;
    }
    if (tech != "all" && tech != "wifi" && tech != "zigbee" && tech != "bluetooth")
    {
        std::cerr << "Invalid --tech value. Use wifi, zigbee, bluetooth, or all." << std::endl;
        return 1;
    }

    std::vector<std::string> techs;
    if (tech == "all")
    {
        techs.push_back("wifi");
        techs.push_back("zigbee");
        techs.push_back("bluetooth");
    }
    else
    {
        techs.push_back(tech);
    }

    std::vector<double> speeds;
    speeds.push_back(1.0);
    speeds.push_back(2.0);
    speeds.push_back(5.0);
    speeds.push_back(10.0);

    std::ofstream res(outFile.c_str());
    res << "tech,speed_mps,run,tx_packets,rx_packets,lost_packets,pdr_percent,loss_percent,"
           "throughput_kbps,avg_delay_ms,avg_jitter_ms,avg_rss_dbm\n";
    std::ofstream rss(rssOut.c_str());
    rss << "tech,speed_mps,run,time_s,flow,rss_dbm\n";

    for (uint32_t t = 0; t < techs.size(); ++t)
    {
        for (uint32_t s = 0; s < speeds.size(); ++s)
        {
            for (uint32_t run = 1; run <= runs; ++run)
            {
                std::cout << "Running " << techs[t] << "  speed=" << speeds[s] << " m/s  run=" << run
                          << " ..." << std::endl;
                Result r = RunOne(techs[t], speeds[s], run, p, rss);
                res << r.tech << "," << r.speed << "," << r.run << "," << r.tx << "," << r.rx << ","
                    << r.lost << "," << r.pdr << "," << r.lossPct << "," << r.thrKbps << ","
                    << r.delayMs << "," << r.jitterMs << "," << r.rssDbm << "\n";
                res.flush();
                std::cout << "   PDR=" << r.pdr << "%  Throughput=" << r.thrKbps
                          << " kbps  Delay=" << r.delayMs << " ms  RSS=" << r.rssDbm << " dBm"
                          << std::endl;
            }
        }
    }

    res.close();
    rss.close();
    std::cout << "\nDone. Wrote " << outFile << " and " << rssOut << std::endl;
    return 0;
}
