#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/error-model.h"

#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include <algorithm>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TcpVanetComparison");

static std::string g_protocol = "TcpReno";
static std::ofstream g_cwndFile;
static std::map<uint32_t, double> g_cwndSum;
static std::map<uint32_t, uint64_t> g_cwndSamples;
static std::map<uint32_t, uint32_t> g_cwndMax;

static void
CwndChange(uint32_t oldCwnd, uint32_t newCwnd)
{
    (void)oldCwnd;
    uint32_t nodeId = 0;
    // The trace path callback does not identify its socket/node. The global trace
    // below therefore writes a time-series record; the node field is set to -1.
    g_cwndFile << std::fixed << std::setprecision(6)
               << Simulator::Now().GetSeconds() << ","
               << g_protocol << ",-1," << newCwnd << "\n";
}

static void
ConnectCwndTraces()
{
    Config::ConnectWithoutContext(
        "/NodeList/*/$ns3::TcpL4Protocol/SocketList/*/CongestionWindow",
        MakeCallback(&CwndChange));
}

static void
WriteHelp()
{
    std::cout << "Options:\n"
              << "  --protocol=TcpReno|TcpCubic|TcpBbr\n"
              << "  --bottleneckMbps=5\n"
              << "  --vehicleRateMbps=5\n"
              << "  --simTime=30\n"
              << "  --packetSize=1400\n"
              << "  --runLabel=run1\n\n"
              << "Note: TcpBbr availability depends on the installed ns-3 version.\n";
}

int
main(int argc, char *argv[])
{
    std::string protocol = "TcpReno";
    double bottleneckMbps = 5.0;
    double vehicleRateMbps = 5.0;
    double simTime = 30.0;
    uint32_t packetSize = 1400;
    std::string runLabel = "run1";

    CommandLine cmd(__FILE__);
    cmd.AddValue("protocol", "TCP congestion control: TcpReno, TcpCubic, or TcpBbr", protocol);
    cmd.AddValue("bottleneckMbps", "RSU-to-Internet bottleneck capacity in Mbps", bottleneckMbps);
    cmd.AddValue("vehicleRateMbps", "Offered TCP application rate per vehicle in Mbps", vehicleRateMbps);
    cmd.AddValue("simTime", "Simulation duration in seconds", simTime);
    cmd.AddValue("packetSize", "TCP application packet size in bytes", packetSize);
    cmd.AddValue("runLabel", "Label used in output filenames", runLabel);
    cmd.Parse(argc, argv);

    if (protocol != "TcpReno" && protocol != "TcpCubic" && protocol != "TcpBbr")
    {
        std::cerr << "Invalid protocol: " << protocol << "\n";
        WriteHelp();
        return 1;
    }

    // Check that this ns-3 build actually contains the requested TCP TypeId.
    TypeId tcpType;
    if (!TypeId::LookupByNameFailSafe("ns3::" + protocol, &tcpType))
    {
        std::cerr << "This ns-3 build does not contain ns3::" << protocol << ".\n"
                  << "Use a version/build that includes it, or select TcpReno/TcpCubic.\n";
        return 2;
    }

    g_protocol = protocol;
    std::string prefix = "tcp_vanet_" + protocol + "_" + runLabel;
    g_cwndFile.open(prefix + "_cwnd.csv");
    g_cwndFile << "time_s,protocol,node_id,cwnd_bytes\n";

    Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(tcpType));
    Config::SetDefault("ns3::TcpSocket::SegmentSize", UintegerValue(packetSize));

    // Five vehicles send concurrent TCP traffic to one traffic-control server.
    NodeContainer vehicles;
    vehicles.Create(5);
    Ptr<Node> rsuRouter = CreateObject<Node>();
    Ptr<Node> internetRouter = CreateObject<Node>();
    Ptr<Node> server = CreateObject<Node>();

    InternetStackHelper internet;
    internet.Install(vehicles);
    internet.Install(rsuRouter);
    internet.Install(internetRouter);
    internet.Install(server);

    // Vehicle-to-RSU access links model the wireless access hop at a simplified
    // link level. The shared RSU-to-Internet link is the congestion bottleneck.
    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate", StringValue("20Mbps"));
    access.SetChannelAttribute("Delay", StringValue("2ms"));

    Ipv4AddressHelper address;
    Ipv4InterfaceContainer vehicleIfaces;
    std::vector<NetDeviceContainer> accessDevices;
    for (uint32_t i = 0; i < 5; ++i)
    {
        NodeContainer pair(vehicles.Get(i), rsuRouter);
        NetDeviceContainer devices = access.Install(pair);
        accessDevices.push_back(devices);

        std::ostringstream subnet;
        subnet << "10.1." << (i + 1) << ".0";
        address.SetBase(subnet.str().c_str(), "255.255.255.0");
        Ipv4InterfaceContainer iface = address.Assign(devices);
        vehicleIfaces.Add(iface.Get(0));
    }

    PointToPointHelper bottleneck;
    std::ostringstream bottleneckRate;
    bottleneckRate << bottleneckMbps << "Mbps";
    bottleneck.SetDeviceAttribute("DataRate", StringValue(bottleneckRate.str()));
    bottleneck.SetChannelAttribute("Delay", StringValue("20ms"));
    NetDeviceContainer bottleneckDevices = bottleneck.Install(rsuRouter, internetRouter);
    address.SetBase("10.2.0.0", "255.255.255.0");
    Ipv4InterfaceContainer bottleneckIfaces = address.Assign(bottleneckDevices);

    PointToPointHelper serverLink;
    serverLink.SetDeviceAttribute("DataRate", StringValue("20Mbps"));
    serverLink.SetChannelAttribute("Delay", StringValue("10ms"));
    NetDeviceContainer serverDevices = serverLink.Install(internetRouter, server);
    address.SetBase("10.3.0.0", "255.255.255.0");
    Ipv4InterfaceContainer serverIfaces = address.Assign(serverDevices);

    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    uint16_t basePort = 5000;
    ApplicationContainer sinks;
    ApplicationContainer sources;

    for (uint32_t i = 0; i < 5; ++i)
    {
        uint16_t port = basePort + i;
        PacketSinkHelper sinkHelper("ns3::TcpSocketFactory",
                                    InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApp = sinkHelper.Install(server);
        sinkApp.Start(Seconds(0.0));
        sinkApp.Stop(Seconds(simTime));
        sinks.Add(sinkApp);

        OnOffHelper sourceHelper("ns3::TcpSocketFactory",
                                 InetSocketAddress(serverIfaces.GetAddress(1), port));
        std::ostringstream appRate;
        appRate << vehicleRateMbps << "Mbps";
        sourceHelper.SetAttribute("DataRate", DataRateValue(DataRate(appRate.str())));
        sourceHelper.SetAttribute("PacketSize", UintegerValue(packetSize));
        sourceHelper.SetAttribute("OnTime",
                                  StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        sourceHelper.SetAttribute("OffTime",
                                  StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        ApplicationContainer sourceApp = sourceHelper.Install(vehicles.Get(i));
        sourceApp.Start(Seconds(1.0 + 0.1 * i));
        sourceApp.Stop(Seconds(simTime - 0.5));
        sources.Add(sourceApp);
    }

    // Congestion-window trace is recorded as a time series. node_id is -1 because
    // the generic Config trace path does not provide node/socket identity.
    Simulator::Schedule(Seconds(0.5), &ConnectCwndTraces);

    FlowMonitorHelper flowmonHelper;
    Ptr<FlowMonitor> monitor = flowmonHelper.InstallAll();

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowmonHelper.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    std::ofstream flowFile(prefix + "_flows.csv");
    flowFile << "protocol,condition,flow_id,source,destination,tx_packets,rx_packets,"
                "lost_packets,throughput_mbps,avg_delay_ms,packet_loss_percent,rx_bytes\n";

    // Jain fairness index is calculated across the five vehicle flows.
    std::vector<double> perVehicleThroughput(5, 0.0);
    std::vector<uint64_t> perVehicleRxBytes(5, 0);
    std::vector<double> perVehicleDelayMs(5, 0.0);
    std::vector<double> perVehicleLossPct(5, 0.0);
    std::vector<uint64_t> perVehicleTx(5, 0);
    std::vector<uint64_t> perVehicleRx(5, 0);
    std::vector<double> perVehicleDelaySum(5, 0.0);

    for (const auto &entry : stats)
    {
        Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(entry.first);
        const FlowMonitor::FlowStats &st = entry.second;

        // Keep only TCP flows whose destination is the server and port is in our range.
        if (tuple.destinationPort < basePort || tuple.destinationPort >= basePort + 5)
            continue;

        uint32_t vehicleIndex = tuple.destinationPort - basePort;
        double activeDuration = std::max(0.001, simTime - 1.0);
        double throughputMbps = (st.rxBytes * 8.0) / (activeDuration * 1e6);
        double avgDelayMs = st.rxPackets > 0
                                ? (st.delaySum.GetSeconds() * 1000.0 / st.rxPackets)
                                : 0.0;
        double lossPct = st.txPackets > 0
                             ? (100.0 * (st.txPackets - std::min(st.txPackets, st.rxPackets)) /
                                st.txPackets)
                             : 0.0;

        perVehicleThroughput[vehicleIndex] += throughputMbps;
        perVehicleRxBytes[vehicleIndex] += st.rxBytes;
        perVehicleTx[vehicleIndex] += st.txPackets;
        perVehicleRx[vehicleIndex] += st.rxPackets;
        perVehicleDelaySum[vehicleIndex] += st.delaySum.GetSeconds();
        perVehicleDelayMs[vehicleIndex] = avgDelayMs;
        perVehicleLossPct[vehicleIndex] = lossPct;

        flowFile << protocol << ",congestion," << entry.first << ","
                 << tuple.sourceAddress << ":" << tuple.sourcePort << ","
                 << tuple.destinationAddress << ":" << tuple.destinationPort << ","
                 << st.txPackets << "," << st.rxPackets << "," << st.lostPackets << ","
                 << std::fixed << std::setprecision(6) << throughputMbps << ","
                 << avgDelayMs << "," << lossPct << "," << st.rxBytes << "\n";
    }
    flowFile.close();

    double sum = 0.0, sumSquares = 0.0, totalThroughput = 0.0;
    double totalDelayWeighted = 0.0;
    uint64_t totalTx = 0, totalRx = 0, totalLost = 0;
    for (uint32_t i = 0; i < 5; ++i)
    {
        double t = perVehicleThroughput[i];
        sum += t;
        sumSquares += t * t;
        totalThroughput += t;
        totalTx += perVehicleTx[i];
        totalRx += perVehicleRx[i];
        totalLost += (perVehicleTx[i] > perVehicleRx[i] ? perVehicleTx[i] - perVehicleRx[i] : 0);
        if (perVehicleRx[i] > 0)
            totalDelayWeighted += perVehicleDelayMs[i] * perVehicleRx[i];
    }
    double fairness = sumSquares > 0 ? (sum * sum) / (5.0 * sumSquares) : 0.0;
    double overallLossPct = totalTx > 0
                                ? 100.0 * (totalTx - std::min(totalTx, totalRx)) / totalTx
                                : 0.0;
    double overallDelayMs = totalRx > 0 ? totalDelayWeighted / totalRx : 0.0;

    std::ofstream summary(prefix + "_summary.csv");
    summary << "protocol,condition,bottleneck_mbps,vehicle_rate_mbps,total_throughput_mbps,"
               "avg_delay_ms,packet_loss_percent,jain_fairness,tx_packets,rx_packets,lost_packets\n";
    summary << protocol << ",congestion," << bottleneckMbps << "," << vehicleRateMbps << ","
            << std::fixed << std::setprecision(6) << totalThroughput << ","
            << overallDelayMs << "," << overallLossPct << "," << fairness << ","
            << totalTx << "," << totalRx << "," << totalLost << "\n";
    summary.close();

    std::cout << "\n=== VANET TCP congestion-control results ===\n"
              << "Protocol: " << protocol << "\n"
              << "Vehicle flows: 5\n"
              << "Bottleneck: " << bottleneckMbps << " Mbps\n"
              << "Offered rate per vehicle: " << vehicleRateMbps << " Mbps\n"
              << "Aggregate throughput: " << totalThroughput << " Mbps\n"
              << "Average end-to-end delay: " << overallDelayMs << " ms\n"
              << "Packet loss estimate: " << overallLossPct << " %\n"
              << "Jain fairness index: " << fairness << " (closer to 1 is fairer)\n"
              << "Files: " << prefix << "_flows.csv, " << prefix
              << "_summary.csv, " << prefix << "_cwnd.csv\n";

    Simulator::Destroy();
    g_cwndFile.close();
    return 0;
}
