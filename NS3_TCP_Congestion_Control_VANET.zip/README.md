# NS-3 TCP Congestion Control Comparison for a VANET

## Goal
Compare **TCP Reno**, **TCP Cubic**, and **TCP BBR** for five vehicles sending traffic updates/camera-related data through a roadside unit (RSU), a constrained Internet link, and a traffic-control server.

The shared RSU-to-Internet point-to-point link is deliberately the bottleneck. Five simultaneous TCP flows compete for its capacity, creating congestion.

## Important modelling note
This is an **educational, simplified VANET model**. Each vehicle-to-RSU access hop is represented by a point-to-point link, not a full IEEE 802.11p/802.11bd or LTE/5G radio model. It isolates TCP congestion-control behaviour and makes the shared bottleneck easy to analyse. If your instructor requires actual wireless VANET channel/mobility, extend the topology with Wi-Fi/802.11p or a supported vehicular module.

TCP BBR is not present in every ns-3 release/build. The program checks whether `ns3::TcpBbr` exists and exits with an informative error if it does not. Use an ns-3 version that includes BBR, or omit BBR only if your instructor permits. Do not label a different algorithm as BBR.

## Topology

```text
Vehicle 1 --\
Vehicle 2 ---\
Vehicle 3 ----> RSU Router ----[BOTTLENECK]---- Internet Router ---- Traffic Control Server
Vehicle 4 ---/
Vehicle 5 --/
```

- 5 vehicle source nodes; one TCP flow per vehicle
- Vehicle-to-RSU links: 20 Mbps, 2 ms
- RSU-to-Internet bottleneck: default 5 Mbps, 20 ms
- Internet-to-server link: 20 Mbps, 10 ms
- Default offered application rate: 5 Mbps per vehicle (25 Mbps aggregate offered load)
- Default simulation time: 30 s

These are simulation assumptions, not measurements from a real road network.

## Files
- `scratch/tcp_vanet_comparison.cc` — NS-3 C++ simulation
- `analysis/plot_results.py` — plots aggregate throughput, delay, packet loss, fairness, and congestion-window samples
- `results/` — CSV templates (not measured results)
- `VIVA.md` — viva questions and short answers
- `REPORT_TEMPLATE.md` — report structure and discussion guide

## Run
Copy `scratch/tcp_vanet_comparison.cc` into the `scratch/` directory of your ns-3 checkout.

From the ns-3 root, compile once:

```bash
./ns3 build
```

Run each algorithm separately:

```bash
./ns3 run "scratch/tcp_vanet_comparison --protocol=TcpReno --runLabel=reno"
./ns3 run "scratch/tcp_vanet_comparison --protocol=TcpCubic --runLabel=cubic"
./ns3 run "scratch/tcp_vanet_comparison --protocol=TcpBbr --runLabel=bbr"
```

You can change the congestion level by lowering the bottleneck rate or raising each vehicle's offered rate:

```bash
./ns3 run "scratch/tcp_vanet_comparison --protocol=TcpReno --bottleneckMbps=3 --vehicleRateMbps=6 --simTime=30 --runLabel=reno_heavy"
```

Repeat the same settings for Cubic and BBR when comparing them. Only change the protocol between comparison runs.

The output CSV files are created in the **current working directory**:
- `tcp_vanet_<protocol>_<label>_flows.csv`
- `tcp_vanet_<protocol>_<label>_summary.csv`
- `tcp_vanet_<protocol>_<label>_cwnd.csv`

If your ns-3 version uses a different build/run command, follow that version's instructions.

## Plot the results
After running all three protocols, copy their summary CSV rows into `results/comparison_summary.csv` (template provided), and run:

```bash
python3 analysis/plot_results.py --summary results/comparison_summary.csv
```

To plot congestion-window samples, combine the three `*_cwnd.csv` files into `results/comparison_cwnd.csv` and run:

```bash
python3 analysis/plot_results.py --cwnd results/comparison_cwnd.csv
```

Install `matplotlib` if required: `python3 -m pip install matplotlib`.

## Metrics
- **Throughput (Mbps):** received bytes × 8 / measurement interval / 1,000,000
- **Average delay (ms):** mean FlowMonitor end-to-end delay for received packets
- **Packet loss (%):** estimated from transmitted versus received packets; TCP retransmissions and FlowMonitor accounting mean this is an approximation, so report the method clearly
- **Jain fairness index:** `(sum of per-flow throughput)^2 / (N × sum of squared per-flow throughput)`, where `N=5`; 1 means perfectly equal throughput
- **Congestion window (cwnd):** trace in bytes; use time-series plot to compare growth and fluctuations

### Interpretation cautions
- TCP retransmission, FlowMonitor's packet accounting, and application-level goodput are not identical. Treat the loss percentage as a simulation estimate, not a direct count of unique application messages lost.
- A generic Config trace path records cwnd values but does not tag the node/socket, so `node_id` is `-1`. It is a combined time series; do not interpret it as one particular vehicle's cwnd.
- BBR is model/version dependent. Results vary with ns-3 version, random seed, topology, offered load, buffer size, and algorithm implementation.
- The code has been prepared as a study template and has not been compiled against your specific ns-3 installation. Build it in your lab environment and resolve any version-specific API differences before submission.
