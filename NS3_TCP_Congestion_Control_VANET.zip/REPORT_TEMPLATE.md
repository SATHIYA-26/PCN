# Simulation and Performance Analysis of TCP Congestion Control Algorithms using NS-3

## 1. Aim
To compare TCP Reno, TCP Cubic, and TCP BBR under congestion in a simplified VANET-to-server scenario.

## 2. Scenario
Five vehicles send TCP traffic through an RSU router and a shared, constrained Internet link to a traffic-control server. The RSU-to-Internet link is the bottleneck.

## 3. Topology and parameters
| Parameter | Value |
|---|---|
| Vehicle source nodes | 5 |
| TCP flows | 5 |
| Vehicle-to-RSU link | 20 Mbps, 2 ms |
| RSU-to-Internet bottleneck | 5 Mbps, 20 ms |
| Internet-to-server link | 20 Mbps, 10 ms |
| Offered application rate | 5 Mbps per vehicle |
| Simulation duration | 30 s |
| Algorithms | TCP Reno, TCP Cubic, TCP BBR (if supported by installed ns-3) |

These are configured simulation values, not real-world measurements.

## 4. Algorithm background
- **Reno:** loss-based; adjusts cwnd based on acknowledgements and loss signals.
- **Cubic:** loss-based; cubic window growth is designed to scale on high bandwidth-delay paths.
- **BBR:** model-based; estimates bottleneck bandwidth and propagation RTT, then paces sending.

## 5. Metrics and formulas
- Throughput (Mbps) = received bytes × 8 / measurement interval / 10^6
- Average delay (ms) = mean end-to-end delay of received packets
- Packet loss estimate (%) = 100 × (transmitted packets − received packets) / transmitted packets
- Jain fairness = (sum of per-flow throughput)^2 / (number of flows × sum of squared per-flow throughput)
- Congestion window = TCP sender cwnd in bytes over time

State clearly that the loss figure is an approximate FlowMonitor/IP-layer metric and can be affected by TCP retransmission accounting.

## 6. Results
Fill this table only with values produced by your own simulation.

| Algorithm | Throughput (Mbps) | Delay (ms) | Packet loss (%) | Jain fairness | cwnd behaviour |
|---|---:|---:|---:|---:|---|
| TCP Reno | | | | | |
| TCP Cubic | | | | | |
| TCP BBR | | | | | |

Insert generated graphs:
1. Throughput by algorithm
2. Delay by algorithm
3. Packet-loss estimate by algorithm
4. Jain fairness by algorithm
5. Congestion window versus time

## 7. Discussion
Explain each result using the observed CSV data. Do not assume one algorithm must win every metric. Discuss bottleneck rate, offered load, queueing, RTT, implementation version, and run-to-run variability.

## 8. Importance to intelligent transportation
Low delay matters for collision warnings, emergency braking, road hazards, and traffic-signal coordination. Reliable delivery matters for camera uploads, road-condition reports, and traffic management data. However, some extremely time-critical broadcast safety messages use UDP or specialised protocols rather than TCP because TCP's retransmissions and connection behaviour can add latency.

## 9. Limitations
This project abstracts each vehicle-to-RSU access hop as point-to-point and does not model full vehicular radio propagation, interference, mobility, or handovers. BBR availability depends on ns-3 version. The cwnd trace is aggregated and not associated with a specific vehicle socket.

## 10. Conclusion
Write a conclusion supported by the measured results. Avoid claiming a universal winner; TCP congestion-control performance depends on network conditions and implementation.
