# Version and implementation notes

- This is an **NS-3 C++** simulation, not a standalone C program.
- `TcpReno` and `TcpCubic` are commonly available, but exact availability depends on the ns-3 release/build.
- `TcpBbr` is not included in every ns-3 release/build. The code uses a TypeId lookup before setting the TCP socket type; it stops rather than silently substituting another algorithm.
- Some versions may require minor API adjustments. If the compiler complains about a trace signature or helper API, check the documentation for the exact ns-3 release installed in the lab.
- The vehicle-to-RSU link is abstracted as point-to-point. For a true VANET PHY/MAC study, add a wireless vehicular model and mobility; do not claim this simplified link models IEEE 802.11p channel behaviour.
- The congestion window trace is a combined trace with `node_id=-1`; it is useful to inspect the aggregate time series, but it does not identify each vehicle's socket separately.
- `FlowMonitor` counts IP-layer flows and can include effects of TCP retransmissions. The CSV's loss percentage is an approximate transmitted-vs-received calculation; explain this limitation in the report.
