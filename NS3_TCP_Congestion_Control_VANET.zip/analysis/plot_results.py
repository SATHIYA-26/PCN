#!/usr/bin/env python3
import argparse
import csv
import os
from collections import defaultdict

def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))

def plot_summary(path):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise SystemExit("Install matplotlib first: python3 -m pip install matplotlib")

    rows = read_csv(path)
    if not rows:
        raise SystemExit("No rows found in summary CSV.")
    outdir = os.path.dirname(os.path.abspath(path))
    metrics = [
        ("total_throughput_mbps", "Aggregate throughput (Mbps)", "throughput_by_algorithm.png"),
        ("avg_delay_ms", "Average end-to-end delay (ms)", "delay_by_algorithm.png"),
        ("packet_loss_percent", "Packet loss estimate (%)", "packet_loss_by_algorithm.png"),
        ("jain_fairness", "Jain fairness index", "fairness_by_algorithm.png"),
    ]
    for field, ylabel, filename in metrics:
        labels, values = [], []
        for row in rows:
            try:
                values.append(float(row[field]))
                labels.append(row["protocol"])
            except (KeyError, ValueError):
                continue
        if not values:
            continue
        plt.figure()
        plt.bar(labels, values)
        plt.ylabel(ylabel)
        plt.xlabel("TCP algorithm")
        plt.title(ylabel + " by algorithm")
        plt.tight_layout()
        target = os.path.join(outdir, filename)
        plt.savefig(target, dpi=160)
        plt.close()
        print("Saved", target)

def plot_cwnd(path):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        raise SystemExit("Install matplotlib first: python3 -m pip install matplotlib")
    rows = read_csv(path)
    grouped = defaultdict(list)
    for row in rows:
        try:
            grouped[row["protocol"]].append((float(row["time_s"]), float(row["cwnd_bytes"])))
        except (KeyError, ValueError):
            continue
    plt.figure()
    for protocol, points in grouped.items():
        points.sort()
        plt.plot([p[0] for p in points], [p[1] for p in points], label=protocol)
    plt.xlabel("Time (s)")
    plt.ylabel("Congestion window (bytes)")
    plt.title("TCP congestion-window trace (combined socket trace)")
    plt.legend()
    plt.tight_layout()
    target = os.path.join(os.path.dirname(os.path.abspath(path)), "congestion_window_comparison.png")
    plt.savefig(target, dpi=160)
    plt.close()
    print("Saved", target)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", help="CSV containing one summary row per algorithm")
    parser.add_argument("--cwnd", help="Combined congestion-window CSV")
    args = parser.parse_args()
    if not args.summary and not args.cwnd:
        parser.error("Provide --summary and/or --cwnd")
    if args.summary:
        plot_summary(args.summary)
    if args.cwnd:
        plot_cwnd(args.cwnd)

if __name__ == "__main__":
    main()
