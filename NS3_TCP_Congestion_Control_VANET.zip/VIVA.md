# Viva: TCP Congestion Control in a VANET using NS-3

## Core concepts
1. **What is TCP congestion control?** It adjusts the sending rate/window to avoid overloading the network.
2. **What is a VANET?** A Vehicular Ad Hoc Network: vehicles communicate with other vehicles, RSUs, or infrastructure.
3. **What is an RSU?** Roadside Unit; a fixed communication point near the road that can relay vehicle data to infrastructure.
4. **Why is congestion likely here?** Five vehicles offer 25 Mbps in total while the shared link is only 5 Mbps.
5. **What is the congestion window (cwnd)?** The sender's limit on unacknowledged data in flight due to congestion control.
6. **What is throughput?** Successfully received data per unit time.
7. **What is end-to-end delay?** Time for a packet to travel from source to destination, including queuing and transmission effects.
8. **What is packet loss?** Packets that do not arrive; loss can trigger TCP retransmission and reduce sending rate.
9. **What is fairness?** How evenly the available bandwidth is shared among flows.
10. **What is Jain's fairness index?** `(sum(x))^2 / (N * sum(x^2))`; closer to 1 means more equal allocation.

## Algorithm comparison
11. **TCP Reno:** Classic loss-based congestion control. It increases cwnd cautiously and reduces it when congestion/loss is detected.
12. **TCP Cubic:** Loss-based algorithm with a cubic window-growth function; commonly used as the default on Linux and designed to scale well on high-bandwidth/high-delay paths.
13. **TCP BBR:** Model-based congestion control. It estimates bottleneck bandwidth and round-trip propagation time to pace traffic. It does not use packet loss as its primary congestion signal, though queues/loss can still occur.
14. **Which one always gives the highest throughput?** None universally. The outcome depends on RTT, bottleneck, queue, competing flows, implementation, and parameters.
15. **Which one always gives the lowest delay?** None universally. BBR aims to operate near estimated bottleneck bandwidth and propagation delay, but results depend on the BBR version and queue dynamics.
16. **Why can Reno's throughput fall?** Loss signals congestion, causing Reno to reduce cwnd.
17. **Why can Cubic suit high-speed networks?** Its cubic growth function allows faster window growth at larger bandwidth-delay products.
18. **Why is low delay important in intelligent transportation?** Alerts about collisions, emergency braking, road hazards, and signal changes lose value if delivered too late.
19. **Why is reliability important?** Missing or delayed safety messages can lead to incorrect traffic decisions; TCP reliability helps for data that requires ordered, reliable delivery.
20. **Is TCP ideal for every safety message?** Not necessarily. Some time-critical broadcast safety messages use UDP or specialised protocols because connection setup/retransmission can add delay. TCP is useful for reliable streams, camera uploads, logs, and server-bound data.
21. **What is the bottleneck link in this model?** The RSU-router-to-Internet-router link.
22. **Why use multiple simultaneous flows?** To create contention and compare how algorithms share constrained capacity.
23. **What does cwnd plot show?** Window growth and reductions over time; it helps explain throughput changes.
24. **What is a simulation seed?** A seed controls pseudorandom choices so runs can be repeated or varied systematically.
25. **Why run repeated trials?** To reduce dependence on one run and compare mean and variability.

## One-line memory aid
- **Reno:** loss-based, conservative increase and multiplicative decrease.
- **Cubic:** loss-based, cubic growth, scales well at high bandwidth-delay products.
- **BBR:** model-based, estimates bottleneck bandwidth and propagation RTT.
