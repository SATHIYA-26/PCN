#!/usr/bin/env python3
import argparse,csv,json,os,socket,time,uuid
from datetime import datetime
def valid(h):
    if not isinstance(h,str) or not h or len(h)>253:return False
    if h.lower()=="localhost":return True
    labels=h.rstrip(".").split(".")
    return len(labels)>=2 and all(0<len(x)<=63 and x[0]!="-" and x[-1]!="-" and all(c.isalnum() or c=="-" for c in x) for x in labels)
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--server",default="127.0.0.1");p.add_argument("--port",type=int,default=53535)
    p.add_argument("--timeout",type=float,default=1.5);p.add_argument("--cache-ttl",type=int,default=60)
    p.add_argument("--csv",default="results/client_metrics.csv");p.add_argument("--queries",nargs="*")
    a=p.parse_args();os.makedirs(os.path.dirname(os.path.abspath(a.csv)),exist_ok=True)
    fresh=not os.path.exists(a.csv) or os.path.getsize(a.csv)==0
    with open(a.csv,"a",newline="",encoding="utf-8") as f:
        w=csv.writer(f)
        if fresh:w.writerow(["timestamp","hostname","status","ip","cache_hit","latency_ms","bytes_sent","bytes_received","timed_out"])
    cache={};s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.settimeout(a.timeout)
    qlist=a.queries; interactive=qlist is None
    if interactive: print("DNS client: try example.com, repeat it, not-a-real-domain.invalid, bad/name; quit to exit.")
    try:
        while True:
            if interactive:
                try:h=input("Domain> ").strip()
                except EOFError:break
                if h.lower() in ("quit","exit","q"):break
            else:
                if not qlist:break
                h=qlist.pop(0)
            start=time.perf_counter();key=h.lower().rstrip(".");now=time.monotonic()
            sent=recv=0;timeout=False;hit=False
            if not h or not valid(h):
                status,value="FORMERR","invalid hostname format";ms=(time.perf_counter()-start)*1000
            elif key in cache and cache[key][0]>now:
                _,status,value=cache[key];hit=True;ms=(time.perf_counter()-start)*1000
            else:
                cache.pop(key,None);rid=uuid.uuid4().hex[:12];payload=json.dumps({"id":rid,"hostname":h}).encode();sent=len(payload)
                try:
                    s.sendto(payload,(a.server,a.port));raw,_=s.recvfrom(4096);recv=len(raw);res=json.loads(raw.decode())
                    ms=(time.perf_counter()-start)*1000
                    if res.get("id")!=rid:status,value="BAD_RESPONSE","response ID mismatch"
                    else:status,value=res.get("status","BAD_RESPONSE"),res.get("ip",res.get("message","unknown"))
                    if status in ("NOERROR","NXDOMAIN"):cache[key]=(time.monotonic()+max(1,min(a.cache_ttl,int(res.get("ttl",a.cache_ttl))),),status,value)
                except socket.timeout:ms=(time.perf_counter()-start)*1000;status,value="TIMEOUT","no response before timeout";timeout=True
                except (OSError,ValueError,UnicodeDecodeError) as e:ms=(time.perf_counter()-start)*1000;status,value="ERROR",str(e)
            print(f"{status:10} {h:32} -> {value} | {ms:.3f} ms | cache={'HIT' if hit else 'MISS'}")
            with open(a.csv,"a",newline="",encoding="utf-8") as f:
                csv.writer(f).writerow([datetime.now().isoformat(timespec="milliseconds"),h,status,value if status=="NOERROR" else "",int(hit),f"{ms:.6f}",sent,recv,int(timeout)])
    finally:s.close();print("Metrics saved to",a.csv)
if __name__=="__main__":main()
