#!/usr/bin/env python3
import argparse, json, socket, time
from datetime import datetime

DNS_DB={"example.com":"93.184.216.34","google.com":"142.250.72.14","openai.com":"104.18.33.45","ssn.edu.in":"203.110.245.10","mit.edu":"23.36.76.17","wikipedia.org":"208.80.154.224","localhost":"127.0.0.1"}
def valid(h):
    if not isinstance(h,str) or not h or len(h)>253: return False
    if h.lower()=="localhost": return True
    labels=h.rstrip(".").split(".")
    return len(labels)>=2 and all(0<len(x)<=63 and x[0]!="-" and x[-1]!="-" and all(c.isalnum() or c=="-" for c in x) for x in labels)
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--host",default="127.0.0.1"); p.add_argument("--port",type=int,default=53535)
    p.add_argument("--timeout-demo",action="store_true"); p.add_argument("--log",default="server.log")
    a=p.parse_args()
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.bind((a.host,a.port))
    print(f"UDP DNS simulation server on {a.host}:{a.port}. Ctrl+C to stop.")
    try:
        while True:
            raw,addr=s.recvfrom(4096); start=time.perf_counter()
            try:
                req=json.loads(raw.decode()); host=req.get("hostname"); rid=req.get("id","")
                if not isinstance(host,str) or not valid(host):
                    res={"id":rid,"status":"FORMERR","message":"invalid hostname/request format"}
                elif a.timeout_demo and host.lower().rstrip(".")=="timeout.demo":
                    print("Dropping timeout.demo request intentionally"); continue
                else:
                    key=host.lower().rstrip(".")
                    res=({"id":rid,"status":"NOERROR","hostname":host,"ip":DNS_DB[key],"ttl":60}
                         if key in DNS_DB else {"id":rid,"status":"NXDOMAIN","hostname":host,"message":"domain not found"})
            except (ValueError,UnicodeDecodeError,AttributeError):
                res={"id":"","status":"FORMERR","message":"request must be JSON with hostname"}
            s.sendto(json.dumps(res).encode(),addr)
            ms=(time.perf_counter()-start)*1000
            print(f'{res["status"]:8} {res.get("hostname","-"):28} {res.get("ip",res.get("message",""))} ({ms:.3f} ms)')
            with open(a.log,"a",encoding="utf-8") as f: f.write(f"{datetime.now().isoformat()},{res.get('status')},{res.get('hostname','')},{ms:.3f}\\n")
    except KeyboardInterrupt: print("\\nServer stopped.")
    finally: s.close()
if __name__=="__main__": main()
