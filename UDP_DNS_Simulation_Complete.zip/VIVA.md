# Viva — UDP DNS Simulation

1. **What is DNS?** DNS maps hostnames such as example.com to IP addresses.
2. **Aim?** Simulate DNS client/server using UDP and study cache, error handling, latency, and overhead.
3. **Why UDP?** No connection handshake; small queries can be sent with low overhead and latency.
4. **Does UDP guarantee delivery?** No; UDP does not guarantee delivery, order, or retransmission.
5. **How is reliability handled?** Application timeout and retry logic; real DNS may use TCP in certain cases.
6. **What is NXDOMAIN?** Requested domain name does not exist.
7. **What is FORMERR here?** Simulation response for invalid request/hostname format.
8. **What is timeout?** No response arrived before the client's configured wait period.
9. **How is timeout simulated?** Start server with `--timeout-demo`; it drops query `timeout.demo`.
10. **What is caching?** Saving a recent result locally to avoid repeating a network lookup.
11. **What is TTL?** Time to live: how long a cached answer can be reused.
12. **Cache hit ratio?** Cache hits / total queries × 100%.
13. **Why is cache hit faster?** It avoids network transmission and server wait.
14. **How is latency measured?** Client-side elapsed time around lookup processing or timeout.
15. **What metrics are collected?** Latency, cache hit/miss, timeout, byte counts, status counts.
16. **Is this real DNS?** No, JSON over UDP is used for teaching; real DNS has a standard wire format.
17. **What is SOCK_DGRAM?** Datagram socket type used for UDP.
18. **What is sendto()?** Sends a datagram to a destination address.
19. **What is recvfrom()?** Receives a datagram and sender address.
20. **What if domain is not in dictionary?** Server responds NXDOMAIN.
21. **Caching limitation?** Data can become stale until cache TTL expires.
22. **UDP vs TCP?** UDP is connectionless and low overhead; TCP provides reliable ordered byte-stream delivery.
23. **Why localhost?** Client and server can communicate on the same computer without external network.
24. **What is a DNS table?** Mapping of hostname keys to IP address values.
25. **Why analyse graphs?** To show query latency and compare cache hits, misses, and timeouts using measured data.
