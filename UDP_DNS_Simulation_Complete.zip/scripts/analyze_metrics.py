#!/usr/bin/env python3
import argparse,csv,os,statistics
def main():
    p=argparse.ArgumentParser();p.add_argument("--input",default="results/client_metrics.csv");p.add_argument("--outdir",default="graphs");a=p.parse_args()
    if not os.path.exists(a.input):raise SystemExit("Run the client first: "+a.input+" not found")
    with open(a.input,newline="",encoding="utf-8") as f:rows=list(csv.DictReader(f))
    if not rows:raise SystemExit("No query records yet")
    try:import matplotlib.pyplot as plt
    except ImportError:raise SystemExit("Install matplotlib: python -m pip install matplotlib")
    os.makedirs(a.outdir,exist_ok=True)
    lat=[];hitlat=[];misslat=[]
    for r in rows:
        try:
            x=float(r["latency_ms"]);lat.append(x);(hitlat if r["cache_hit"]=="1" else misslat).append(x)
        except (KeyError,ValueError):pass
    hits=sum(r.get("cache_hit")=="1" for r in rows);timeouts=sum(r.get("timed_out")=="1" for r in rows);n=len(rows)
    with open(os.path.join(a.outdir,"summary.txt"),"w",encoding="utf-8") as f:
        f.write(f"Total queries: {n}\\nCache hits: {hits}\\nCache hit ratio: {hits/n*100:.2f}%\\nTimeouts: {timeouts}\\n")
        f.write(f"Mean latency: {statistics.mean(lat):.3f} ms\\nMedian latency: {statistics.median(lat):.3f} ms\\n" if lat else "No latency data\\n")
        f.write("Status counts:\\n")
        for k in sorted(set(r.get("status","") for r in rows)):f.write(f"  {k}: {sum(r.get('status')==k for r in rows)}\\n")
    print(open(os.path.join(a.outdir,"summary.txt"),encoding="utf-8").read())
    plt.figure();plt.plot(range(1,len(lat)+1),lat,marker="o");plt.xlabel("Query number");plt.ylabel("Latency (ms)");plt.title("DNS query latency");plt.tight_layout();plt.savefig(os.path.join(a.outdir,"latency_by_query.png"),dpi=160);plt.close()
    plt.figure();plt.bar(["Cache hit","Cache miss"],[statistics.mean(hitlat) if hitlat else 0,statistics.mean(misslat) if misslat else 0]);plt.ylabel("Mean latency (ms)");plt.title("Cache hit vs miss latency");plt.tight_layout();plt.savefig(os.path.join(a.outdir,"cache_latency_comparison.png"),dpi=160);plt.close()
    plt.figure();plt.bar(["Hits","Misses","Timeouts"],[hits,n-hits,timeouts]);plt.ylabel("Number of queries");plt.title("Query summary");plt.tight_layout();plt.savefig(os.path.join(a.outdir,"query_summary.png"),dpi=160);plt.close()
    print("Graphs saved to",a.outdir)
if __name__=="__main__":main()
