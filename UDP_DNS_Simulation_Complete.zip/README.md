# UDP DNS Simulation — Complete Lab Project

This is a Python UDP-socket **DNS-like educational simulation**, not a standards-compliant DNS implementation. It includes a hostname→IP dictionary, client-side TTL cache, NXDOMAIN, invalid format, timeout simulation, metrics CSV, graphs, viva, and report template.

## Project files
- `src/dns_server.py` — UDP server / simulated DNS table
- `src/dns_client.py` — client, validation, TTL cache, timeout, CSV logging
- `scripts/analyze_metrics.py` — metrics summary and graphs
- `VIVA.md` — viva Q&A
- `REPORT_TEMPLATE.md` — report structure
- `results/` and `graphs/` — generated outputs

## Requirements
Python 3.9+; no external library for client/server. `matplotlib` is needed only for graphs.

## Run on Windows PowerShell
Open Terminal 1 in the extracted project folder:
```powershell
python src/dns_server.py
```
Leave it running. Open Terminal 2 in the same folder:
```powershell
python src/dns_client.py
```
Try these inputs:
- `example.com` — successful lookup
- `ssn.edu.in` — successful lookup from the sample table
- `example.com` again — cache hit, no network query
- `not-a-real-domain.invalid` — NXDOMAIN
- `bad/name` — FORMERR
- `timeout.demo` — timeout only when server uses `--timeout-demo`

### Enable timeout test
Stop server and start:
```powershell
python src/dns_server.py --timeout-demo
```
In client, enter `timeout.demo`. The server intentionally drops it, so client waits until timeout. Change wait time:
```powershell
python src/dns_client.py --timeout 1
```

### Non-interactive test batch
Start server first, then in another terminal:
```powershell
python src/dns_client.py --queries example.com example.com ssn.edu.in not-a-real-domain.invalid bad/name
```
Timeout batch with server `--timeout-demo`:
```powershell
python src/dns_client.py --timeout 1 --queries timeout.demo
```

## Performance analysis
Client automatically appends rows to `results/client_metrics.csv`: query status, cache hit, observed latency, request/response bytes, and timeout flag.
Install plotting library:
```powershell
python -m pip install matplotlib
```
Then run:
```powershell
python scripts/analyze_metrics.py
```
It generates `graphs/summary.txt`, `latency_by_query.png`, `cache_latency_comparison.png`, and `query_summary.png`. These graphs use your actual run data. Repeat a domain before TTL expires to observe a cache hit. Results depend on the machine and should not be fabricated.

## UDP suitability
UDP avoids a connection handshake, so it has low overhead for small query/response messages. It can provide low latency. UDP itself does not guarantee delivery, ordering, or retransmission, so a resolver uses timeouts/retries. Real DNS can also use TCP for truncated responses and other cases. Caching reduces repeated network queries and latency.

## Limitations
Uses JSON messages, not DNS wire-format packets. Does not implement recursive resolution, DNSSEC, authoritative zones, full TTL rules, or all real DNS error semantics. Timeout is simulated by dropping a specific request. For local lab testing, default localhost binding is safest.
