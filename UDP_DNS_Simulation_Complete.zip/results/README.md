The client creates client_metrics.csv when run. Results are measured by your own execution; no fabricated measurements are included.
