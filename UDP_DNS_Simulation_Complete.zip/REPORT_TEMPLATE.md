# Simulation of Domain Name Resolution Using UDP Socket Programming

## 1. Aim
Develop a UDP client/server simulating DNS lookup with hostname-to-IP dictionary, client-side cache, NXDOMAIN, timeout, invalid-format handling, and performance analysis.

## 2. Design
Client validates the hostname, checks local TTL cache, sends UDP request on cache miss, waits for response, logs metrics, and caches positive/negative answers. Server parses JSON, validates hostname, checks the dictionary, and responds with NOERROR, NXDOMAIN, or FORMERR. Timeout-demo mode intentionally drops `timeout.demo`.

## 3. Test cases
| Input | Expected result |
|---|---|
| `example.com` | NOERROR and sample IP |
| Repeat `example.com` before TTL expires | Cache hit |
| `not-a-real-domain.invalid` | NXDOMAIN |
| `bad/name` | FORMERR |
| `timeout.demo` with `--timeout-demo` | Client timeout |
| Empty input | FORMERR at client |

## 4. Performance metrics
- Client-observed latency (ms)
- Cache hit ratio = hits / total queries × 100%
- Timeout count
- Request/response byte counts
- Mean and median latency

Insert generated graphs from `graphs/`. Report actual values from your run.

## 5. UDP suitability
UDP has low overhead because it avoids connection establishment. This helps small DNS queries achieve low latency. UDP itself does not guarantee delivery, order, or retransmission, so clients use timeouts and retries. Real DNS can use TCP for certain cases. Client caching reduces network traffic and lookup latency.

## 6. Limitations
Educational JSON-over-UDP simulation, not standard DNS wire format. It does not implement recursion, DNSSEC, authoritative zones, full TTL semantics, or all DNS error handling.

## 7. Conclusion
Discuss your measured latency, cache hit ratio, and timeout behaviour. Do not invent results; use the CSV and graphs produced by your run.
