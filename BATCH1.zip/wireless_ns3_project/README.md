# Wi-Fi vs ZigBee vs Bluetooth Performance Comparison in ns-3

This project simulates three wireless technologies with moving (mobile) nodes, measures
their performance, and draws comparison graphs.

| File | What it is |
|---|---|
| `wireless_comparison.cc` | The ns-3 simulation (C++). Builds the networks, creates traffic, moves the nodes, measures everything and writes CSV files. |
| `plot_results.py` | Python script. Reads the CSV files and draws the comparison graphs. |
| `README.md` | This guide. |

---

## 1. The big picture (read this first)

### 1.1 What is ns-3?
ns-3 is a **network simulator**: a C++ program library that imitates, inside a computer,
what real network hardware would do. Nothing is transmitted over real air. Instead, the
simulator keeps a virtual clock and a list of events ("at t = 2.0 s node A sends a packet",
"at t = 2.001 s node B receives it"), and processes them in time order. This lets you test
networks that would be expensive or impossible to build physically, and repeat experiments
exactly.

### 1.2 Basic building blocks used in the code
* **Node** - a device (phone, sensor, access point, laptop). It starts as an empty box.
* **NetDevice** - the radio "card" installed in a node (Wi-Fi card, 802.15.4 radio).
* **Channel** - the shared air between the radios. It decides how much signal power
  reaches the receiver (path loss) and how long the signal takes to travel.
* **Protocol stack** - IP addresses, routing, UDP, etc. installed on each node.
* **Application** - the software that creates traffic. We use a UDP **client** (sends
  packets at a fixed rate) and a UDP **server** (receives and counts them).
* **Topology** - which nodes exist, where they are, and who talks to whom.

### 1.3 Mobility and the Random Walk model
A *mobility model* tells the simulator where a node is at every moment.
**RandomWalk2d** works like a person wandering without a destination: every 1 second the
node picks a new random direction and walks in that direction at a fixed speed. If it
reaches the border of the 50 m x 50 m area, it bounces back. We repeat every experiment
with speeds **1, 2, 5 and 10 m/s** (walking -> running -> vehicle-like). A faster node
wanders farther, so the distance between communicating nodes changes more quickly.

### 1.4 Received Signal Strength (RSS)
When a radio transmits with power `Ptx` (in dBm), the signal gets weaker with distance.
The model used here is **log-distance path loss**:

```
PathLoss(d) = 46.68 dB + 10 * 3 * log10(d)        (d in metres, exponent 3)
RSS (dBm)   = Ptx (dBm) - PathLoss(d)
```
The farther apart two nodes are, the lower (more negative) the RSS, e.g. -50 dBm is
strong, -90 dBm is weak. Below roughly -90 dBm the receiver cannot decode packets, so
packets are lost. The program samples the RSS of every communicating pair every 0.5 s and
stores it (`rss_trace.csv`); the average goes into `results.csv`.

### 1.5 Performance metrics (definitions)
| Metric | Meaning | Formula |
|---|---|---|
| **Packets sent / received / lost** | Counted for all UDP flows | lost = sent - received |
| **PDR** (Packet Delivery Ratio) = **packet success rate** | Percentage of sent packets that arrived | `received / sent x 100` |
| **Packet loss %** | Percentage that did not arrive | `100 - PDR` |
| **Throughput** | Useful data delivered per second (application level) | `received x payload_bytes x 8 / active_time` (kbps) |
| **Delay** | Average time from sending to receiving a packet | `sum(delay) / received` (ms) |
| **Jitter** | Average variation of delay between consecutive packets (smaller = steadier) | from FlowMonitor (ms) |
| **RSS** | Signal power at the receiver | see 1.4 (dBm) |

---

## 2. IMPORTANT: how each technology is modelled (be honest in your report)

| Technology | How it is built in this project | Real or approximation? |
|---|---|---|
| **Wi-Fi** | ns-3 `wifi` module, 802.11g, **2 access points** (fixed) and **2 mobile stations**. Station 0 is associated to AP0 and station 1 to AP1 (different SSIDs). Each station sends UDP to its AP. Adaptive data rate (IdealWifiManager), default 16 dBm power. | Real ns-3 model |
| **ZigBee** | ns-3 `lr-wpan` module = **IEEE 802.15.4** radio + MAC (250 kbps, 0 dBm) with 6LoWPAN/IPv6 and UDP. 2 mobile nodes send to each other. | 802.15.4 is the radio/MAC layer ZigBee is built on. The ZigBee network/application layers do not exist in standard ns-3, so they are not modelled. |
| **Bluetooth** | **ns-3 has no official Bluetooth model.** It is approximated by a short-range 1 Mbps radio (802.11b DSSS 1 Mbps, ad-hoc, 0 dBm) between 2 mobile nodes. | **Approximation** (data rate, power and range are Bluetooth-like, but hopping, piconet scheduling and slots are not modelled). |

Say this clearly in your report/viva. Using a third-party Bluetooth module is the only way
to get a "true" Bluetooth model.

### Topology summary
```
 50 m x 50 m area, all mobile nodes use RandomWalk2d

 Wi-Fi     :  AP0 (12.5,25) <-- STA0 (starts 17.5,25)      AP1 (37.5,25) <-- STA1 (starts 32.5,25)
              2 flows (STA0->AP0, STA1->AP1)
 ZigBee    :  Node0 (starts 20,25) <----> Node1 (starts 30,25)     2 flows (both directions)
 Bluetooth :  Mobile0 (starts 20,25) <--> Mobile1 (starts 30,25)   2 flows (both directions)
```
Default traffic per flow: UDP, 64-byte payload, one packet every 20 ms (=25.6 kbps),
starting at 2 s and ending at 60 s. Each technology therefore receives the same offered load.

---

## 3. Prerequisites

ns-3 runs on **Linux** (or macOS). If you use Windows 10/11, install **WSL2** with Ubuntu
(`wsl --install -d Ubuntu` in PowerShell, then restart) or use a Linux virtual machine,
and do all the steps below inside the Ubuntu terminal.

You need: a C++ compiler, CMake, Python 3, and ns-3 (version 3.36 or newer; 3.40 is a good choice).

---

## 4. Step-by-step: install ns-3 (skip if you already have it)

Open the Ubuntu terminal and type:

```bash
sudo apt update
sudo apt install -y g++ python3 python3-pip cmake ninja-build git wget tar bzip2
cd ~
wget https://www.nsnam.org/releases/ns-allinone-3.40.tar.bz2
tar xjf ns-allinone-3.40.tar.bz2
cd ns-allinone-3.40/ns-3.40
./ns3 configure --enable-examples
./ns3 build
```
The build takes 10-40 minutes the first time. Make sure the `lr-wpan`, `sixlowpan`, `wifi`
and `flow-monitor` modules are included (they are by default).
After this, **`~/ns-allinone-3.40/ns-3.40` is your "ns-3 folder"** used below.

---

## 5. Step-by-step: run the C++ simulation

1. **Unzip this project** somewhere, e.g. `~/wireless_ns3_project`.
2. **Copy the C++ file into the ns-3 `scratch` folder:**
   ```bash
   cp ~/wireless_ns3_project/wireless_comparison.cc ~/ns-allinone-3.40/ns-3.40/scratch/
   ```
3. **Go to the ns-3 folder:**
   ```bash
   cd ~/ns-allinone-3.40/ns-3.40
   ```
4. **Build and run** (default: all three technologies, 4 speeds, 3 runs each = 36 simulations):
   ```bash
   ./ns3 run wireless_comparison
   ```
   (The first time it compiles the file; fix any error shown, then run again.)
   You will see lines such as
   `Running wifi  speed=1 m/s  run=1 ...` followed by the PDR, throughput, delay and RSS.
5. **Wait until** you see `Done. Wrote results.csv and rss_trace.csv`.
   The two CSV files are created in the ns-3 folder you are standing in.
6. **Copy the CSV files next to the Python script:**
   ```bash
   cp results.csv rss_trace.csv ~/wireless_ns3_project/
   ```

### Optional command-line options
```bash
./ns3 run "wireless_comparison --runs=1"                 # quick test (12 simulations)
./ns3 run "wireless_comparison --tech=zigbee"            # only one technology (wifi|zigbee|bluetooth)
./ns3 run "wireless_comparison --simTime=100"            # longer simulation
./ns3 run "wireless_comparison --interval=2 --out=heavy.csv --rssOut=heavy_rss.csv"
                                                          # heavy traffic (500 packets/s per flow)
```
Light traffic (20 ms) shows differences mainly in RSS, loss and delay. **Heavy traffic
(`--interval=2`) pushes ZigBee and Bluetooth to their capacity limits and makes the
throughput differences between the three technologies obvious.** Run both and compare.

---

## 6. Step-by-step: draw the graphs with Python

1. Install the libraries (once):
   ```bash
   pip3 install pandas matplotlib
   ```
2. Go to the project folder (where `results.csv` was copied):
   ```bash
   cd ~/wireless_ns3_project
   ```
3. Run:
   ```bash
   python3 plot_results.py
   ```
   For the heavy-traffic files:
   ```bash
   python3 plot_results.py --results heavy.csv --rss heavy_rss.csv --outdir plots_heavy
   ```
4. Open the `plots` folder. (On WSL, type `explorer.exe plots` to open it in Windows.)

### Output of the Python script (`plots/` folder)
| File | Content |
|---|---|
| `throughput_kbps.png`, `avg_delay_ms.png`, `avg_jitter_ms.png`, `pdr_percent.png`, `loss_percent.png`, `avg_rss_dbm.png` | One graph per metric: x = node speed, one line per technology, error bars = spread over the runs |
| `all_metrics.png` | All six graphs in one picture (good for a report page) |
| `rss_vs_time.png` | RSS against time, one panel per technology, one line per speed |
| `summary_table.csv` | The averaged numbers for your report table |

---

## 7. How to read the results (expected behaviour)
* **RSS** drops as nodes drift apart. Wi-Fi has the strongest signal (16 dBm vs 0 dBm).
* **PDR / loss**: Wi-Fi is the most robust. The Bluetooth-like 0 dBm link has the shortest
  range, so it loses more packets when nodes drift apart. ZigBee has good sensitivity,
  so it usually keeps links alive at longer distance.
* **Throughput**: with light traffic all technologies deliver about what was sent
  (minus losses). With heavy traffic: Wi-Fi (tens of Mbps) >> Bluetooth-like (~1 Mbps) > ZigBee (250 kbps radio).
* **Delay / jitter**: Wi-Fi lowest; ZigBee highest because of its slow 250 kbps radio and CSMA back-off.
* **Speed effect**: higher speed means distances change faster, so results vary more
  between runs (bigger error bars). Because motion is random, the trend is not always a perfectly
  straight line; more runs (`--runs=10`) give smoother curves.

Your own numbers decide the conclusions: describe what **your** graphs show.

---

## 8. What to write in your report / assignment (template)

**Title:** Performance comparison of Wi-Fi, ZigBee and Bluetooth under RandomWalk mobility using ns-3

1. **Aim** - Build topologies for Wi-Fi (2 APs, 2 stations), ZigBee (2 nodes) and Bluetooth
   (2 mobiles), generate UDP traffic, vary node speed (1, 2, 5, 10 m/s) with the RandomWalk
   mobility model and compare RSS, packet success rate (PDR), throughput, delay, jitter and loss.
2. **Tools** - ns-3 (version used), Ubuntu/WSL, Python 3 with pandas and matplotlib.
3. **Topology** - include the diagram from section 2 and the table of positions.
4. **Simulation parameters** - table: area 50 x 50 m, simulation time 60 s, traffic start 2 s,
   packet size 64 B, interval 20 ms, mobility RandomWalk2d (1 s direction change), speeds
   1/2/5/10 m/s, propagation LogDistance (exponent 3), Wi-Fi 802.11g 16 dBm, ZigBee 802.15.4
   0 dBm, Bluetooth approximation 1 Mbps 0 dBm, 3 runs per case.
5. **Procedure** - the steps of sections 5 and 6 in your own words.
6. **Results** - paste `all_metrics.png`, the individual graphs, `rss_vs_time.png` and the table `summary_table.csv`.
7. **Observations / discussion** - for each metric write 2-3 sentences based on your graphs
   (e.g. "Throughput of ZigBee stays near X kbps because ..."; "PDR of Bluetooth falls from X% at 1 m/s to Y% at 10 m/s because the
   nodes drift outside its short range and the RSS drops below the receiver sensitivity").
8. **Limitations** - Bluetooth is approximated; ZigBee upper layers are not modelled; free-space-like
   path loss, no walls or interference from other devices; only 2 flows.
9. **Conclusion** - which technology is best for which situation (Wi-Fi: high data rate and range;
   ZigBee: low power, low rate sensor data; Bluetooth: short-range personal-area links), supported by your numbers.

---

## 9. Troubleshooting
| Problem | Fix |
|---|---|
| `./ns3: command not found` | You are not inside the ns-3 folder (`cd ~/ns-allinone-3.40/ns-3.40`). |
| Compile error about `WIFI_STANDARD_80211g` or `WIFI_PHY_STANDARD_...` | You use an ns-3 older than 3.36. Install 3.36 or newer (section 4). |
| Error: `lr-wpan` / `sixlowpan` not found | Re-configure: `./ns3 configure --enable-examples` then `./ns3 build`. |
| `GetClassifier6` not a member | Old ns-3. Use 3.36 or newer. |
| Program finds `results.csv` missing in Python | Copy `results.csv` and `rss_trace.csv` to the folder where you run `plot_results.py`, or pass their path with `--results` and `--rss`. |
| ZigBee PDR is 0 % | Make sure `--simTime` is larger than 4 s (traffic starts at 2 s) and the build had no warnings about lr-wpan. |
| Graphs look jagged | Increase `--runs` (e.g. 10) for better averaging. |
| `ModuleNotFoundError: pandas` | `pip3 install pandas matplotlib` |
| Want to start fresh | `rm results.csv rss_trace.csv` and run again. |
