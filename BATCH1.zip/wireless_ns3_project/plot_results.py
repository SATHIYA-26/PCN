#!/usr/bin/env python3
"""
plot_results.py
---------------
Reads the CSV files produced by the ns-3 program (wireless_comparison.cc) and draws
comparison graphs of Wi-Fi vs ZigBee vs Bluetooth for every performance metric.

Usage:
    python3 plot_results.py
    python3 plot_results.py --results results.csv --rss rss_trace.csv --outdir plots
    python3 plot_results.py --show        # also open the graph windows
"""

import argparse
import os
import sys

import matplotlib

parser = argparse.ArgumentParser(description="Plot ns-3 Wi-Fi / ZigBee / Bluetooth results")
parser.add_argument("--results", default="results.csv", help="results CSV from ns-3")
parser.add_argument("--rss", default="rss_trace.csv", help="RSS trace CSV from ns-3")
parser.add_argument("--outdir", default="plots", help="folder where graphs are saved")
parser.add_argument("--show", action="store_true", help="show windows as well")
args = parser.parse_args()

if not args.show:
    matplotlib.use("Agg")  # no display needed, just save PNG files

import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

if not os.path.exists(args.results):
    sys.exit(f"ERROR: '{args.results}' not found. Run the ns-3 simulation first.")

os.makedirs(args.outdir, exist_ok=True)

LABELS = {
    "wifi": "Wi-Fi (802.11g, 2 APs)",
    "zigbee": "ZigBee (802.15.4)",
    "bluetooth": "Bluetooth (approx.)",
}
COLORS = {"wifi": "tab:blue", "zigbee": "tab:green", "bluetooth": "tab:red"}
MARKERS = {"wifi": "o", "zigbee": "s", "bluetooth": "^"}

# (column in CSV, y-axis label, graph title)
METRICS = [
    ("throughput_kbps", "Throughput (kbps)", "Throughput vs Node Speed"),
    ("avg_delay_ms", "Average delay (ms)", "End-to-End Delay vs Node Speed"),
    ("avg_jitter_ms", "Average jitter (ms)", "Jitter vs Node Speed"),
    ("pdr_percent", "Packet Delivery Ratio (%)", "PDR (Packet Success Rate) vs Node Speed"),
    ("loss_percent", "Packet loss (%)", "Packet Loss vs Node Speed"),
    ("avg_rss_dbm", "Average RSS (dBm)", "Received Signal Strength vs Node Speed"),
]

df = pd.read_csv(args.results)
techs = [t for t in ["wifi", "zigbee", "bluetooth"] if t in df["tech"].unique()]

# average over the repeated runs (mean) and keep the spread (std)
mean = df.groupby(["tech", "speed_mps"]).mean(numeric_only=True).reset_index()
std = df.groupby(["tech", "speed_mps"]).std(numeric_only=True).fillna(0).reset_index()


def draw(ax, col, ylabel, title):
    for t in techs:
        m = mean[mean["tech"] == t].sort_values("speed_mps")
        s = std[std["tech"] == t].sort_values("speed_mps")
        ax.errorbar(
            m["speed_mps"],
            m[col],
            yerr=s[col],
            label=LABELS[t],
            color=COLORS[t],
            marker=MARKERS[t],
            capsize=3,
            linewidth=2,
        )
    ax.set_xlabel("Node speed (m/s)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_xticks(sorted(df["speed_mps"].unique()))
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.legend()


# 1) one PNG per metric
for col, ylabel, title in METRICS:
    fig, ax = plt.subplots(figsize=(7, 4.5))
    draw(ax, col, ylabel, title)
    fig.tight_layout()
    fig.savefig(os.path.join(args.outdir, f"{col}.png"), dpi=150)
    if not args.show:
        plt.close(fig)

# 2) all metrics together in one picture
fig, axes = plt.subplots(2, 3, figsize=(17, 9))
for ax, (col, ylabel, title) in zip(axes.flat, METRICS):
    draw(ax, col, ylabel, title)
fig.suptitle("Wi-Fi vs ZigBee vs Bluetooth under RandomWalk mobility", fontsize=15)
fig.tight_layout()
fig.savefig(os.path.join(args.outdir, "all_metrics.png"), dpi=150)
if not args.show:
    plt.close(fig)

# 3) RSS against time (from rss_trace.csv)
if os.path.exists(args.rss):
    rss = pd.read_csv(args.rss)
    rss = rss[rss["run"] == rss["run"].min()]  # first run only, keeps the graph readable
    fig, axes = plt.subplots(1, len(techs), figsize=(6 * len(techs), 4.5), squeeze=False)
    for ax, t in zip(axes[0], techs):
        sub = rss[rss["tech"] == t]
        for spd, g in sub.groupby("speed_mps"):
            line = g.groupby("time_s")["rss_dbm"].mean()
            ax.plot(line.index, line.values, label=f"{spd:g} m/s")
        ax.set_title(f"RSS vs time - {LABELS[t]}")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("RSS (dBm)")
        ax.grid(True, linestyle="--", alpha=0.5)
        ax.legend(title="Node speed")
    fig.tight_layout()
    fig.savefig(os.path.join(args.outdir, "rss_vs_time.png"), dpi=150)
    if not args.show:
        plt.close(fig)
else:
    print(f"(note) '{args.rss}' not found - skipping the RSS-vs-time graph")

# 4) summary table
cols = ["tech", "speed_mps"] + [c for c, _, _ in METRICS]
summary = mean[cols].round(3)
summary.to_csv(os.path.join(args.outdir, "summary_table.csv"), index=False)
print("\nAverage values (over all runs):\n")
print(summary.to_string(index=False))
print(f"\nGraphs and summary_table.csv saved in the '{args.outdir}' folder.")

if args.show:
    plt.show()
