# Assignment 10 Report Template

## Title
Comparative Evaluation of Routing Protocols Using NS-3

## Objective
To study routing behavior under normal traffic, congestion and link-failure conditions using NS-3.

## Topology
Describe the nodes, routers, sources, destinations, link rates, delays, queue sizes and alternate path.

## Protocol implementation and validity
Explicitly identify the implementation and version used for each protocol:
- RIP: [module/version or state that it is an approximation]
- OSPF: [module/version or state that it is an approximation]
- AODV: [module/version and topology type]

Do not label global routing as actual OSPF or RIP.

## Traffic configuration
Document UDP/CBR packet size, data rate, start/stop times, number of flows and simulation duration.

## Scenarios
1. Normal network condition
2. Congestion condition
3. Intermediate-link failure

## Metrics
- PDR (%)
- Average end-to-end delay (ms)
- Actual routing-table updates/control-plane events
- Optional throughput (Mbps)

## Results
Insert the values measured from your actual simulation runs. Do not invent numeric values.

## Graphs
- PDR vs Network Condition
- End-to-End Delay vs Network Condition
- Routing Table Updates vs Network Condition

## Discussion
Explain how offered load and link failure affected packet delivery, delay and route recovery. Mention topology and protocol limitations.

## Conclusion
Summarize only what the measured results support.
