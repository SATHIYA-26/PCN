/*
 * Assignment 10: Comparative Evaluation of Routing Protocols Using NS-3
 *
 * IMPORTANT IMPLEMENTATION NOTE:
 * Standard ns-3 distributions commonly include AODV and Ipv4GlobalRouting,
 * but do not provide native IPv4 RIP and OSPF protocol implementations in
 * the core distribution. This teaching harness therefore labels:
 *   aodv  = native ns-3 AODV (intended for ad hoc wireless networks)
 *   ospf  = global shortest-path routing proxy (NOT actual OSPF)
 *   rip   = global shortest-path routing proxy (NOT actual RIP)
 *
 * The RIP/OSPF entries are comparative routing-behavior proxies only.
 * Do not claim this program implements the actual RIP or OSPF wire protocols.
 *
 * The topology uses point-to-point links to support deterministic link failure.
 * AODV is primarily designed for ad hoc wireless networks; its use on a
 * point-to-point topology is not a valid AODV evaluation. For a rigorous
 * AODV experiment, adapt the topology to ad hoc Wi-Fi and use a suitable
 * link-failure mechanism. See README.md.
 *
 * Suggested run:
 * ./ns3 run "scratch/routing_comparison --protocol=ospf --condition=normal"
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/aodv-module.h"
#include "ns3/ipv4-global-routing-helper.h"

#include <iomanip>
#include <sstream>
#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("RoutingComparison");

struct LinkInfo
{
    uint32_t a;
    uint32_t b;
    NetDeviceContainer devices;
    Ipv4InterfaceContainer interfaces;
    bool isPrimary;
};

static NodeContainer g_nodes;
static std::vector<LinkInfo> g_links;
static std::string g_protocol;
static bool g_failed = false;
static uint32_t g_routingTableUpdateEvents = 0;
static Ptr<FlowMonitor> g_monitor;
static FlowMonitorHelper* g_flowHelper = nullptr;

static void
DisablePrimaryLink()
{
    // Primary link is the direct link between routers 2 and 3.
    for (auto &link : g_links)
    {
        if (link.isPrimary)
        {
            Ptr<Ipv4> ipv4A = link.devices.Get(0)->GetNode()->GetObject<Ipv4>();
            Ptr<Ipv4> ipv4B = link.devices.Get(1)->GetNode()->GetObject<Ipv4>();
            int32_t ifA = ipv4A->GetInterfaceForDevice(link.devices.Get(0));
            int32_t ifB = ipv4B->GetInterfaceForDevice(link.devices.Get(1));
            if (ifA >= 0) ipv4A->SetDown(static_cast<uint32_t>(ifA));
            if (ifB >= 0) ipv4B->SetDown(static_cast<uint32_t>(ifB));
            g_failed = true;
            ++g_routingTableUpdateEvents; // records the configured failure event
            std::cout << "\n*** LINK FAILURE at " << Simulator::Now().GetSeconds()
                      << " s: disabled link Router2 <-> Router3 ***\n";

            // Recompute global routes for the global-routing proxy modes.
            // AODV route repair must be evaluated on a suitable ad hoc topology.
            if (g_protocol == "ospf" || g_protocol == "rip")
            {
                Ipv4GlobalRoutingHelper::RecomputeRoutingTables();
                ++g_routingTableUpdateEvents;
                std::cout << "*** Global routes recomputed (proxy mode) ***\n";
            }
            return;
        }
    }
}

static void
PeriodicRouteSnapshot()
{
    // This is a sampled snapshot event counter, not a count of actual protocol
    // control-plane updates. It is intentionally labelled as an observation
    // counter in the report to avoid misrepresenting it as true RIP/OSPF/AODV
    // routing-table update telemetry.
    ++g_routingTableUpdateEvents;
    if (Simulator::Now().GetSeconds() < 19.0)
    {
        Simulator::Schedule(Seconds(1.0), &PeriodicRouteSnapshot);
    }
}

static void
PrintResults()
{
    g_monitor->CheckForLostPackets();
    auto stats = g_monitor->GetFlowStats();

    uint64_t txPackets = 0;
    uint64_t rxPackets = 0;
    uint64_t rxBytes = 0;
    uint64_t lostPackets = 0;
    Time delaySum = Seconds(0);
    Time firstRx = Seconds(0);
    Time lastRx = Seconds(0);
    bool hasRx = false;

    for (const auto &entry : stats)
    {
        const FlowMonitor::FlowStats &s = entry.second;
        txPackets += s.txPackets;
        rxPackets += s.rxPackets;
        rxBytes += s.rxBytes;
        lostPackets += s.lostPackets;
        delaySum += s.delaySum;
        if (s.rxPackets > 0)
        {
            if (!hasRx || s.timeFirstRxPacket < firstRx)
                firstRx = s.timeFirstRxPacket;
            if (!hasRx || s.timeLastRxPacket > lastRx)
                lastRx = s.timeLastRxPacket;
            hasRx = true;
        }
    }

    double pdr = txPackets ? 100.0 * rxPackets / txPackets : 0.0;
    double delayMs = rxPackets ? 1000.0 * delaySum.GetSeconds() / rxPackets : 0.0;
    double interval = hasRx ? (lastRx - firstRx).GetSeconds() : 0.0;
    double throughputMbps = interval > 0 ? (rxBytes * 8.0) / (interval * 1e6) : 0.0;

    std::cout << "\n========== RESULTS ==========\n";
    std::cout << "Protocol mode: " << g_protocol << "\n";
    std::cout << "Condition: " << (g_failed ? "link_failure" : "configured_run") << "\n";
    std::cout << "Tx packets: " << txPackets << "\n";
    std::cout << "Rx packets: " << rxPackets << "\n";
    std::cout << "FlowMonitor lost packets: " << lostPackets << "\n";
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "PDR (%): " << pdr << "\n";
    std::cout << "Average end-to-end delay (ms): " << delayMs << "\n";
    std::cout << "Throughput (Mbps): " << throughputMbps << "\n";
    std::cout << "Routing observation/update events (proxy counter): "
              << g_routingTableUpdateEvents << "\n";
    std::cout << "NOTE: this counter is not a true count of protocol routing-table updates.\n";
    std::cout << "=============================\n";

    g_monitor->SerializeToXmlFile("routing-flowmon.xml", true, true);
}

int
main(int argc, char *argv[])
{
    std::string protocol = "ospf";
    std::string condition = "normal";
    uint32_t nFlows = 2;
    std::string dataRate = "512Kbps";
    double failTime = 10.0;
    double simTime = 20.0;
    std::string linkRate = "5Mbps";
    std::string linkDelay = "2ms";

    CommandLine cmd(__FILE__);
    cmd.AddValue("protocol", "Routing mode: rip, ospf, or aodv", protocol);
    cmd.AddValue("condition", "Condition: normal, congestion, or failure", condition);
    cmd.AddValue("nFlows", "Number of simultaneous UDP flows (congestion control)", nFlows);
    cmd.AddValue("dataRate", "Per-flow UDP offered rate", dataRate);
    cmd.AddValue("failTime", "Time to disable primary router link (seconds)", failTime);
    cmd.AddValue("simTime", "Simulation duration (seconds)", simTime);
    cmd.AddValue("linkRate", "Point-to-point data rate", linkRate);
    cmd.AddValue("linkDelay", "Point-to-point propagation delay", linkDelay);
    cmd.Parse(argc, argv);

    if (protocol != "rip" && protocol != "ospf" && protocol != "aodv")
    {
        std::cerr << "Invalid --protocol. Use rip, ospf, or aodv.\n";
        return 1;
    }
    if (condition != "normal" && condition != "congestion" && condition != "failure")
    {
        std::cerr << "Invalid --condition. Use normal, congestion, or failure.\n";
        return 1;
    }

    g_protocol = protocol;
    if (condition == "normal") nFlows = 2;
    if (condition == "congestion") nFlows = std::max<uint32_t>(6, nFlows);
    if (condition == "failure") nFlows = std::max<uint32_t>(2, nFlows);

    // Topology:
    // Source0(0) -- Router2(2) -- Router3(3) -- Destination0(6)
    // Source1(1) -- Router2(2) -- Router4(4) -- Router5(5) -- Router3(3)
    // Destination1(7) -- Router3(3)
    // Router2<->Router3 is the primary link that can fail; alternate path
    // Router2->Router4->Router5->Router3 remains.
    g_nodes.Create(8);

    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue(linkRate));
    p2p.SetChannelAttribute("Delay", StringValue(linkDelay));
    p2p.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("100p"));

    Ipv4AddressHelper address;
    uint32_t subnet = 1;

    auto addLink = [&](uint32_t a, uint32_t b, bool primary) {
        LinkInfo li;
        li.a = a;
        li.b = b;
        li.devices = p2p.Install(g_nodes.Get(a), g_nodes.Get(b));
        std::ostringstream net;
        net << "10.1." << subnet++ << ".0";
        address.SetBase(net.str().c_str(), "255.255.255.0");
        li.interfaces = address.Assign(li.devices);
        li.isPrimary = primary;
        g_links.push_back(li);
    };

    addLink(0, 2, false);
    addLink(1, 2, false);
    addLink(2, 3, true);   // primary link, disabled in failure condition
    addLink(3, 6, false);
    addLink(3, 7, false);
    addLink(2, 4, false);  // alternate path
    addLink(4, 5, false);
    addLink(5, 3, false);

    InternetStackHelper internet;
    if (protocol == "aodv")
    {
        // Included for comparative demonstration only. AODV is designed for
        // ad hoc wireless networks; P2P interfaces are not a valid evaluation
        // topology for AODV route discovery. See README.
        AodvHelper aodv;
        internet.SetRoutingHelper(aodv);
    }
    else
    {
        // Proxy for link-state (ospf label) and distance-vector (rip label).
        // This is ns-3 global routing, NOT native OSPF or RIP.
        Ipv4GlobalRoutingHelper global;
        internet.SetRoutingHelper(global);
    }
    internet.Install(g_nodes);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // UDP sinks on destinations.
    uint16_t portBase = 9000;
    for (uint32_t i = 0; i < 2; ++i)
    {
        PacketSinkHelper sink("ns3::UdpSocketFactory",
            InetSocketAddress(Ipv4Address::GetAny(), portBase + i));
        ApplicationContainer sinkApps = sink.Install(g_nodes.Get(6 + i));
        sinkApps.Start(Seconds(0.5));
        sinkApps.Stop(Seconds(simTime));
    }

    // Each source sends to a destination. Congestion condition adds parallel
    // flows. The topology is intentionally deterministic for lab comparison.
    for (uint32_t i = 0; i < nFlows; ++i)
    {
        uint32_t src = (i % 2 == 0) ? 0 : 1;
        uint32_t dst = (i % 2 == 0) ? 6 : 7;
        uint16_t port = portBase + (i % 2);

        // Find destination's address from its directly attached link.
        Ipv4Address dstAddr("10.1.1.1");
        for (const auto &link : g_links)
        {
            if (link.a == dst || link.b == dst)
            {
                uint32_t devIndex = (link.a == dst) ? 0 : 1;
                dstAddr = link.interfaces.GetAddress(devIndex);
                break;
            }
        }

        OnOffHelper onoff("ns3::UdpSocketFactory",
            InetSocketAddress(dstAddr, port));
        onoff.SetAttribute("DataRate", StringValue(dataRate));
        onoff.SetAttribute("PacketSize", UintegerValue(1024));
        onoff.SetAttribute("OnTime",
            StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        onoff.SetAttribute("OffTime",
            StringValue("ns3::ConstantRandomVariable[Constant=0]"));

        ApplicationContainer app = onoff.Install(g_nodes.Get(src));
        app.Start(Seconds(1.0 + 0.05 * i));
        app.Stop(Seconds(simTime - 0.2));
    }

    FlowMonitorHelper flowHelper;
    g_flowHelper = &flowHelper;
    g_monitor = flowHelper.InstallAll();

    Simulator::Schedule(Seconds(1.0), &PeriodicRouteSnapshot);

    if (condition == "failure")
    {
        Simulator::Schedule(Seconds(failTime), &DisablePrimaryLink);
    }

    Simulator::Stop(Seconds(simTime));
    Simulator::Run();
    PrintResults();
    Simulator::Destroy();
    return 0;
}
