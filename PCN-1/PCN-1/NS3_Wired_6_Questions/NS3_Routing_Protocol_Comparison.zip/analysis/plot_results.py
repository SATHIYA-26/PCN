#!/usr/bin/env python3
"""Plot assignment metrics from a CSV file with columns:
protocol,condition,pdr_percent,avg_delay_ms,routing_updates
"""
import sys
import pandas as pd
import matplotlib.pyplot as plt

if len(sys.argv) != 2:
    print("Usage: python analysis/plot_results.py results/results.csv")
    raise SystemExit(2)

df = pd.read_csv(sys.argv[1])
required = {"protocol", "condition", "pdr_percent", "avg_delay_ms", "routing_updates"}
missing = required - set(df.columns)
if missing:
    raise SystemExit(f"Missing CSV columns: {sorted(missing)}")

order = ["normal", "congestion", "link_failure"]
df["condition"] = pd.Categorical(df["condition"], categories=order, ordered=True)
df = df.sort_values("condition")

plots = [
    ("pdr_percent", "PDR (%)", "pdr_vs_condition.png"),
    ("avg_delay_ms", "Average end-to-end delay (ms)", "delay_vs_condition.png"),
    ("routing_updates", "Routing-table updates / observed events", "routing_updates_vs_condition.png"),
]

for column, ylabel, filename in plots:
    fig, ax = plt.subplots()
    for protocol, group in df.groupby("protocol", observed=False):
        group = group.dropna(subset=[column])
        if not group.empty:
            ax.plot(group["condition"].astype(str), group[column], marker="o", label=protocol.upper())
    ax.set_xlabel("Network condition")
    ax.set_ylabel(ylabel)
    ax.set_title(f"{ylabel} vs Network Condition")
    ax.legend()
    ax.grid(True)
    fig.tight_layout()
    fig.savefig(filename, dpi=160)
    plt.close(fig)
    print(f"Saved {filename}")
