# C / NS-3 Version Notes

This assignment is an NS-3 C++ simulation, not a Winsock/Linux socket-programming assignment.

## Build/run

Copy `scratch/routing_comparison.cc` into the `scratch/` directory of your NS-3 source tree.

From the NS-3 root:

```bash
./ns3 run "scratch/routing_comparison --protocol=ospf --condition=normal"
```

Use the command variations documented in `README.md`.

## Version compatibility

NS-3 APIs vary across releases. Compile and test on the same NS-3 version as your lab. If the build fails, check the exact error and installed API documentation rather than mixing snippets from different releases.

## Important protocol support caveat

Core ns-3 does not generally provide native IPv4 RIP and OSPF implementations. This package uses global routing as a proxy for those two labels and explicitly documents that limitation. AODV is included as a native helper, but the supplied point-to-point topology is not appropriate for a valid AODV route-discovery experiment. See `README.md`.
