# Assignment 10 — Comparative Evaluation of Routing Protocols Using NS-3

## What is included?

- `scratch/routing_comparison.cc` — C++ NS-3 simulation harness
- `analysis/plot_results.py` — plots PDR, delay and routing-observation count from a CSV
- `results/results_template.csv` — CSV template for recording experiment results
- `C_VERSION_NOTES.md` — build/run notes
- `REPORT_TEMPLATE.md` — assignment report outline
- `VIVA.md` — viva questions and answers

## Important accuracy note before submission

A standard ns-3 installation commonly provides **AODV** and **Ipv4GlobalRouting**, but does not provide native IPv4 **RIP** and **OSPF** implementations in the core distribution. This package is therefore a teaching harness, not a standards-complete implementation of all three protocols:

- `--protocol=aodv` selects native ns-3 AODV, but the supplied deterministic point-to-point topology is **not a valid topology for evaluating AODV route discovery**. AODV is designed for ad hoc wireless networks.
- `--protocol=ospf` and `--protocol=rip` select ns-3 global shortest-path routing as a **proxy**. They do not implement OSPF or RIP packet formats, timers, neighbor state, route aging, or actual protocol updates.
- The printed “routing observation/update events” is a simple experiment counter that records periodic observations and the configured failure/recompute event. It is **not** a measured count of real routing-table changes.

Do not label these proxy results as a genuine protocol-level RIP/OSPF/AODV comparison in a formal submission. If the instructor requires real RIP and OSPF, use the required external ns-3 modules or an integrated routing stack and document the exact module/version. For a strict AODV experiment, use an ad hoc Wi-Fi topology and observe AODV routing events.

The code is a practical starting point for learning the topology, traffic, link-failure scheduling, FlowMonitor, CSV analysis and plotting workflow. Check compatibility against your installed ns-3 version before your lab.

## Topology

The topology has eight nodes:

- Node 0 and Node 1: UDP sources
- Nodes 2, 3, 4 and 5: intermediate routers
- Nodes 6 and 7: UDP sinks/destinations

Links:
- 0–2
- 1–2
- 2–3 (primary link; disabled in the failure scenario)
- 3–6
- 3–7
- 2–4
- 4–5
- 5–3

The alternate path after the primary link fails is:
`Router 2 → Router 4 → Router 5 → Router 3`

## Install the source

From the root of your ns-3 directory, copy the source file:

```bash
cp /path/to/NS3_Routing_Protocol_Comparison/scratch/routing_comparison.cc scratch/
```

On Windows, copy the file into the `scratch` directory manually or with PowerShell.

## Run the scenarios

Run commands from the **ns-3 root directory**.

### Normal condition

```bash
./ns3 run "scratch/routing_comparison --protocol=ospf --condition=normal"
./ns3 run "scratch/routing_comparison --protocol=rip --condition=normal"
./ns3 run "scratch/routing_comparison --protocol=aodv --condition=normal"
```

### Congestion condition

```bash
./ns3 run "scratch/routing_comparison --protocol=ospf --condition=congestion --nFlows=6 --dataRate=1Mbps"
./ns3 run "scratch/routing_comparison --protocol=rip --condition=congestion --nFlows=6 --dataRate=1Mbps"
./ns3 run "scratch/routing_comparison --protocol=aodv --condition=congestion --nFlows=6 --dataRate=1Mbps"
```

### Link failure condition

```bash
./ns3 run "scratch/routing_comparison --protocol=ospf --condition=failure --failTime=10"
./ns3 run "scratch/routing_comparison --protocol=rip --condition=failure --failTime=10"
./ns3 run "scratch/routing_comparison --protocol=aodv --condition=failure --failTime=10"
```

**Reminder:** The AODV commands are included to show the option structure only; the supplied point-to-point topology is not suitable for a valid AODV evaluation. The RIP/OSPF modes are global-routing proxies, not actual RIP/OSPF.

The simulation writes `routing-flowmon.xml` to the current working directory.

## Metrics

### Packet Delivery Ratio (PDR)

`PDR (%) = received packets / transmitted packets × 100`

### End-to-end delay

`Average delay (ms) = total received-packet delay / received packets × 1000`

### Routing updates

For this teaching harness, the printed count is an **observation/event counter**, not a real protocol routing-table update count. For a valid protocol comparison, instrument the chosen protocol or collect and analyze routing-table dumps/control-plane traces.

### Optional throughput

`Throughput (Mbps) = received bytes × 8 / receive interval / 1,000,000`

## Graphs

Run the plotting script after recording real run results in `results/results.csv`:

```bash
python analysis/plot_results.py results/results.csv
```

The script creates:
- `pdr_vs_condition.png`
- `delay_vs_condition.png`
- `routing_updates_vs_condition.png`

The plots are based on the CSV values you provide. Do not use blank/template values as measured results.

## Suggested experiment procedure

1. Verify the ns-3 version and compile the source.
2. Run normal, congestion and link-failure conditions for each supported protocol implementation.
3. Keep topology, simulation duration, packet size and baseline flow settings fixed where possible.
4. Record output in `results/results.csv`.
5. Generate the three graphs.
6. Explain observed changes, and clearly state which protocols are native and which are approximations.
7. For a formal result, replace the proxy modes with actual RIP/OSPF implementations and move AODV to a supported ad hoc wireless topology.

## Common troubleshooting

- If `AodvHelper` is not found, ensure the AODV module is built and include `ns3/aodv-module.h`.
- If `SetQueue` or `SerializeToXmlFile` APIs differ, check the ns-3 version installed in your lab.
- If the AODV run produces no useful routes, this is expected to be a limitation of using AODV on point-to-point interfaces.
- If the XML file is not in `scratch/`, check the current working directory used by `./ns3 run`.
