# Viva — Comparative Evaluation of Routing Protocols

## 1. What is routing?
Routing selects a path through a network so packets can reach their destination.

## 2. What is RIP?
RIP (Routing Information Protocol) is a distance-vector routing protocol. It uses hop count as its metric and periodically exchanges routing information. Classic RIP has a maximum usable distance of 15 hops.

## 3. What is OSPF?
OSPF (Open Shortest Path First) is a link-state routing protocol. Routers exchange link-state information and run a shortest-path calculation, commonly Dijkstra's algorithm.

## 4. What is AODV?
AODV (Ad hoc On-Demand Distance Vector) is a reactive routing protocol designed for mobile ad hoc networks. It discovers routes when needed.

## 5. RIP vs OSPF vs AODV
- RIP: distance-vector, periodic route updates, hop-count metric.
- OSPF: link-state, link-state advertisements, shortest-path computation.
- AODV: reactive, route discovery on demand using RREQ/RREP and route-error handling.

## 6. What is congestion?
Congestion occurs when offered traffic exceeds the available network capacity, causing queue growth, delay and potentially packet drops.

## 7. How is congestion introduced in this experiment?
By increasing the number of simultaneous UDP flows and/or their offered data rate.

## 8. What is a link failure?
A network link is made unavailable during simulation to test how routing adapts.

## 9. What is PDR?
PDR (%) = received packets / transmitted packets × 100.

## 10. What is end-to-end delay?
The time a packet takes to travel from the source application to the destination application. Average delay is total delay of received packets divided by received packets.

## 11. What are routing-table updates?
Changes to the forwarding routes maintained by a node as topology or routing information changes. A rigorous comparison must observe actual protocol table changes or control-plane events.

## 12. Why use UDP/CBR traffic?
UDP traffic lets the experiment control the offered packet rate without TCP congestion control changing the sending behavior.

## 13. What is an alternate route?
A different path to the destination used after the original path becomes unavailable.

## 14. Does core ns-3 implement all three protocols natively?
Not generally. AODV is available in standard ns-3; native IPv4 RIP and OSPF implementations are not generally included in the core distribution. This project documents proxy modes and should not be presented as a standards-complete implementation.

## 15. Is global routing the same as OSPF?
No. Global routing computes routes centrally from the known topology for simulation purposes. It does not implement OSPF neighbor discovery, link-state advertisements, protocol timers or OSPF packet exchange.

## 16. Can AODV be meaningfully evaluated on this point-to-point topology?
Not reliably. AODV is designed for ad hoc wireless networking. Use an ad hoc Wi-Fi topology and trace route discovery for a valid AODV evaluation.
